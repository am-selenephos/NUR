# V197 Interaction Registry - Track A

Date: 2026-07-11

Canonical source SHA: `252eee806ece31ef829a2dc5cd45aa8d8f8e855db1bde98b6f87193d786633c3`.

Status law:

- `WIRED`: action reaches a real route/API or persists owner state.
- `SOURCE_NATIVE`: canonical V197 visual/navigation behavior with no server-state claim.
- `HONEST_DISABLED`: visible control is blocked and names the unavailable Track A capability.
- `DEFERRED`: route is an honest 404 until a founder-approved V197-native adjunct exists.

## Entry and auth

| Selector | Action | Backend | Status | Proof |
|---|---|---|---|---|
| `#f4-brand`, `#f4-begin`, `#f4-signin`, `#f4-what`, `[data-switch]`, `#f4-close` | return home/open/switch/close canonical V197 entry chambers | none | `SOURCE_NATIVE` | Track A desktop E2E |
| `#f4-signup-form input`, `#f4-consent-check`, `#f4-signup-form button[type=submit]` | validate and create owner/session/seven Systems | `POST /api/v1/auth/register` | `WIRED` | `track-a-sellable.spec.ts` |
| `#f4-signin-form input`, `#f4-signin-form button[type=submit]` | establish cookie session and enter Universe | `POST /api/v1/auth/login`, `GET /auth/me` | `WIRED` | desktop/mobile/WebKit E2E |

## Navigation and lenses

| Selector | Action | Backend | Status |
|---|---|---|---|
| `[data-page]` | Today/Talk/Journal/Plan/Systems + outer route | owner snapshot reads | `WIRED` |
| `.universe-nav-tabs [data-world-tab]` | Universe/Map/Orbits/Timeline/Insights lens + route | `/universe/*-summary` | `WIRED` |
| `[data-world-focus]` | canonical Research/Community/Web/Consultation/lens focus | Research is real local staging; Community/Consultation are honest states | `WIRED` or `HONEST_DISABLED` by state |
| `.universe-system-node[data-orbit-id]`, `.clean-system-row[data-orbit-id]` | persist selected owner System | `PATCH /profile/preferences` | `WIRED` |
| `.universe-search input` + Enter | owner-ledger search | `GET /universe/search` | `WIRED` |
| `.universe-deep`, `#open-web-search` | open canonical Research focus | local route/read model | `SOURCE_NATIVE` |
| `[data-context-tab]`, `[data-research-tab]` | switch existing V197 local panel | none | `SOURCE_NATIVE` |

## Today, Talk, Journal, Plan, Outcome, Glow

| Selector | Action | Backend | Status |
|---|---|---|---|
| `#today-input`, `[data-send=today]` | persist check-in, Talk turn, and eligible reward | cognition + Talk + Glow APIs | `WIRED` |
| `#talk-input`, `[data-send=talk]`, `#mobile-composer`, `[data-send=mobile]` | persist selected-language Talk | `POST /cognition/talk` | `WIRED` |
| `.universe-prompt-row [data-action]` | set Talk/Plan mode without fake persistence | local mode; send uses Talk/Plan API | `WIRED` |
| `[data-thread-action=private]` | keep thread in owner boundary | no widening action | `SOURCE_NATIVE` |
| `[data-thread-action=journal]` | move latest persisted Talk into Journal draft | local draft only until Save | `WIRED` |
| `[data-thread-action=plan]` | create Plan from latest Talk | `POST /plans` | `WIRED` |
| `[data-thread-action=glow]` | idempotently reward an already persisted Talk | `POST /glow/rewards` | `WIRED` |
| `#journal-input`, `#journal-save` | persist private Journal entry | `POST /journal` | `WIRED` |
| `[data-journal-prompt]` | seed the Journal composer with a canonical prompt | none | `SOURCE_NATIVE` |
| `.plan-check[data-plan-step-id]` | complete/reopen persisted step | `PATCH /plan-steps/:id` | `WIRED` |
| `[data-action=make-easier]` | persist smaller step title | `PATCH /plan-steps/:id` | `WIRED` |
| `#nur-outcome-input`, `[data-action=return-outcome]` | create Outcome, then persisted Glow | `POST /outcomes`, `POST /glow/rewards` | `WIRED` |

## Systems, Research, scope, and hidden modal controls

| Selector | Action | Backend | Status |
|---|---|---|---|
| `#universe-composer-input`, `.universe-send`, `[data-action=add-system]` | Talk/Plan or create owner System according to mode | cognition/plans/orbits | `WIRED` |
| `#research-query`, `[data-research-submit]` | save local research question without invented sources | `POST /research/briefs` | `WIRED` |
| `#scope-open`, `#talk-scope`, `[data-open-scope]`, `.scope-modal-close` | open/close canonical boundary chamber | none | `SOURCE_NATIVE` |
| `[data-context-action]` | explain existing owner boundary/ledger state | none | `SOURCE_NATIVE` |
| `.scope-option[data-scope]`, `.v172-scope-option[data-scope]` | persist owner default boundary | `PATCH /profile/preferences` | `WIRED` |
| `#nur-v197-locale`, `#nur-v197-writing-preference`, `#nur-v197-language-save` | persist language/writing preference | `PATCH /profile/preferences` | `WIRED` |
| `[data-community-tab]`, `[data-stage]`, `.consultation-question button` | explain unavailable Community/Consultation state | none | `HONEST_DISABLED` |
| `[data-action=ritual]` | explain unavailable ritual scheduler | none | `HONEST_DISABLED` |
| `[data-track-a-action=edit-direction]` | explain unavailable Plan direction editor | none | `HONEST_DISABLED` |
| `.composer-action--voice` | explain unavailable voice input | none | `HONEST_DISABLED` |
| `#iSpark`, `#burst-btn`, `.nur-user` | canonical star/burst visual response only | none | `SOURCE_NATIVE` |

## Deferred visual adjuncts

| Route | Status | Reason |
|---|---|---|
| `/capsule/:id` | `DEFERRED` | backend preserved; V197-native recipient document awaits approval |
| `/settings` | `DEFERRED` | preferences are available in the existing scope chamber; no React fallback |
| `/universe/omega*` | `DEFERRED` | owner-only backend preserved; V197-native adjunct awaits approval |

Machine-readable selectors and statuses are in `docs/interaction-registry.json`. `button-registry.spec.ts` checks visible Entry, authenticated, modal, and mobile controls against that file.
