# Existing Backend Reuse Inventory

Date: 2026-07-11

| Domain | Existing backend reused | Track A action |
|---|---|---|
| Auth/session/CSRF | `auth_service.py`, auth router, session cookies | Bound V197 signup/signin; no duplicate auth stack. |
| Orbits and seven Systems | Orbit models/routes and universe summaries | Registration/seed provisions the founder seven; map reads existing endpoints. |
| Cognition/Talk | cognition events, Talk service, model runs, provider abstraction | V197 Talk writes through `/cognition/talk`; disabled provider stays honest. |
| Journal | journal routes/models/conversion | V197 save persists and refreshes owner snapshot. |
| Plan/Outcome | plan, step, experiment, outcome routes | V197 composer, step completion, and Outcome are real. |
| Timeline/Insights | universe summary endpoints and Omega ledgers | Existing owner reads hydrate V197 lenses. |
| Preferences/i18n | profile preferences and migration 0010 | Language/writing preference is persisted and owner-scoped. |
| Research/Community/Web Signals | migration 0010 and product-surface routers | Research staging is wired; Community/Consultation remain honestly disabled visually. |
| Capsule | shared-orbit models, grants, questions, revoke, RLS | Preserved and tested by backend suite; no new Track A visual adjunct. |
| Omega | Omega tables/services/scheduler/review endpoints | Preserved and running; no fake V197 visual adjunct. |
| OpenAI | server provider, schemas, verifier, model runs | Preserved; not rerun with a live key in this disabled-mode packet. |
| Boot/ops | `RUN_NUR.sh`, Postgres, Redis, worker, beat | Reused; status proves all local processes healthy. |

New backend was limited to verified gaps: core Glow persistence/reward rules and translation persistence foundation.

