# Missing Backend Build Map

Date: 2026-07-11

## P0 gaps closed in Track A

- server-owned Glow rules, balance, transactions, streak row, reward events;
- idempotent source/action rewards;
- founder-seven provisioning for new accounts and demo seed;
- translation record foundation with owner RLS;
- V197 write bridge for Auth, Talk, Journal, Plan, Outcome, Research, preferences;
- owner snapshot hydration for Systems and primary lenses.

## Track B backend/product gaps

| Gap | Required build | Dependency/gate |
|---|---|---|
| Full quest/level economy | quest definitions, progress ledger, level rules, anti-abuse, repair economy | outcome integrity and reward analytics |
| Group NUR | groups, memberships, roles, group memory, group Talk, translation boundaries | explicit consent and per-group RLS |
| Community SSR | posts, nested comments, moderation, ranking, reports, notifications | abuse/moderation and public/private split |
| Consultation | room lifecycle, experts, scheduling, bounded transcripts, payment hooks | Capsule-style grants and moderation |
| Live Research/Web | provider connectors, source ingestion, citation verifier, budgets | external-provider consent and provenance |
| AM Projects | project workspaces, agents, artifact/evidence ledger, approval gates | owner control and tool permission model |
| Full translation | locale catalogs, review workflow, dynamic translation provider, cache/invalidation | human review for polished locales |
| Notification retention | preferences, schedules, delivery adapters, quiet hours, experiments | opt-in and harm-aware caps |
| Native adjunct visuals | Capsule, Settings, Omega plain V197 documents | founder approval of adjunct contracts |
| Production scaling | queue partitioning, backups, dashboards, SLOs, deployment hardening | environment-specific operations |

No missing Track B module is presented as live in the Track A interface.

