# Quickstart Boot

Fastest way from the unzipped repository root:

```bash
bash RUN_NUR.sh
```

Then open:

```text
http://localhost:5173
```

Demo credentials are printed by `seed-demo-nur.sh`. Defaults:

```text
Owner: owner@nur.app / owner-demo-pass-123
Recipient: recipient@nur.app / recipient-demo-pass-123
```

OpenAI mode is intentionally not part of the default boot. To configure it
locally after rotating a key:

```bash
bash infra/scripts/configure-openai-local.sh
bash RUN_NUR.sh openai
```

The key is written to `.env.local`, which is ignored and excluded from the
bootable zip.

Useful one-file commands:

```bash
bash RUN_NUR.sh doctor
bash RUN_NUR.sh status
bash RUN_NUR.sh seed
bash RUN_NUR.sh logs
bash RUN_NUR.sh stop
bash RUN_NUR.sh reset-demo
bash RUN_NUR.sh package
```
