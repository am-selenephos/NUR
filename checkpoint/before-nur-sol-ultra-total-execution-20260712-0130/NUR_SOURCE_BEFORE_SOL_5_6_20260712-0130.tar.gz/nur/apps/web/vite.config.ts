import { existsSync, readFileSync } from "node:fs";
import { defineConfig, type Plugin, type PreviewServer, type ViteDevServer } from "vite";
import react from "@vitejs/plugin-react";
import path from "node:path";

const omegaResearchFlag = process.env.VITE_NUR_ENABLE_OMEGA_RESEARCH ?? process.env.NUR_ENABLE_OMEGA_RESEARCH ?? "";
const rootDirectory = __dirname;
const publicV197Directory = path.resolve(rootDirectory, "public/v197");
const canonicalV197Filename = "NUR_V197_CHECKBOX_TICK_RESTORED.html";
const nativeV197Routes = new Set([
  "/",
  "/auth",
  "/onboarding",
  "/today",
  "/talk",
  "/journal",
  "/plan",
  "/systems",
  "/universe",
  "/universe/map",
  "/universe/orbits",
  "/universe/timeline",
  "/universe/insights",
  "/universe/research",
  "/universe/community",
  "/universe/web-signals",
]);
const deferredRoutes = ["/settings", "/capsule/", "/universe/omega"];

function pathname(rawUrl: string | undefined): string {
  return new URL(rawUrl ?? "/", "http://nur.local").pathname;
}

function isDeferredRoute(value: string): boolean {
  return deferredRoutes.some(route => value === route || value.startsWith(route));
}

function composedV197Document(sourcePath: string): string {
  const source = readFileSync(sourcePath, "utf8");
  const bridge = '<script type="module" src="/assets/v197-bridge.js"></script>';
  if (!source.includes("</body>")) throw new Error("Canonical V197 source is missing its closing body tag.");
  // Preserve the canonical file byte-for-byte on disk and at /v197/. Native
  // product routes add only this nonvisual bridge loader after its runtime.
  return source.replace("</body>", `${bridge}</body>`);
}

function v197DirectHost(): Plugin {
  const attach = (server: ViteDevServer | PreviewServer, preview: boolean) => {
    server.middlewares.use((request, response, next) => {
      const route = pathname(request.url);
      if (route === "/assets/v197-bridge.js" && !preview) {
        response.statusCode = 200;
        response.setHeader("content-type", "application/javascript; charset=utf-8");
        response.setHeader("cache-control", "no-store");
        response.end('import "/src/main.ts";');
        return;
      }
      if (isDeferredRoute(route)) {
        response.statusCode = 404;
        response.setHeader("content-type", "text/plain; charset=utf-8");
        response.end("This V197-native adjunct surface is intentionally not available in Phase 1.");
        return;
      }
      if (!nativeV197Routes.has(route)) return next();

      const builtCanonical = path.resolve(rootDirectory, `dist/v197/${canonicalV197Filename}`);
      const canonicalPath = preview && existsSync(builtCanonical)
        ? builtCanonical
        : path.resolve(publicV197Directory, canonicalV197Filename);
      response.statusCode = 200;
      response.setHeader("content-type", "text/html; charset=utf-8");
      response.setHeader("cache-control", "no-store");
      response.end(composedV197Document(canonicalPath));
    });
  };

  return {
    name: "nur-v197-direct-host",
    configureServer(server) {
      attach(server, false);
    },
    configurePreviewServer(server) {
      attach(server, true);
    },
  };
}

export default defineConfig({
  plugins: [v197DirectHost(), react()],
  define: {
    "import.meta.env.VITE_NUR_ENABLE_OMEGA_RESEARCH": JSON.stringify(omegaResearchFlag),
  },
  resolve: {
    alias: { "@nur/shared-types": path.resolve(__dirname, "../../packages/shared-types/src/index.ts") },
  },
  server: {
    port: 5173,
    proxy: { "/api": { target: "http://localhost:8000", changeOrigin: true } },
  },
  preview: {
    proxy: { "/api": { target: "http://localhost:8000", changeOrigin: true } },
  },
  build: {
    rollupOptions: {
      input: path.resolve(rootDirectory, "src/main.ts"),
      output: {
        entryFileNames: "assets/v197-bridge.js",
        chunkFileNames: "assets/v197-[name]-[hash].js",
      },
    },
  },
  test: {
    globals: true,
    environment: "jsdom",
    setupFiles: ["./src/test-setup.ts"],
    css: false,
    include: ["src/**/*.{test,spec}.{ts,tsx}"],
    exclude: ["e2e/**", "node_modules/**"],
  },
});
