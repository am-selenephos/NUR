import { mkdir } from "node:fs/promises";
import { join } from "node:path";

import { expect, test, type Page } from "@playwright/test";

const proofRoot = process.env.NUR_TRACK_A_PROOF_DIR
  ?? (process.cwd().endsWith("/apps/web") ? "../../proof/track-a" : "proof/track-a");

async function shot(page: Page, name: string): Promise<void> {
  await mkdir(proofRoot, { recursive: true });
  await page.screenshot({ path: join(proofRoot, `${name}.png`), fullPage: false, animations: "disabled" });
}

async function criticalMapOverlaps(page: Page): Promise<string[]> {
  return page.frameLocator("#nur-universe-stage").locator("body").evaluate(() => {
    const elements = [
      ...document.querySelectorAll<HTMLElement>(".universe-system-node"),
      document.querySelector<HTMLElement>(".universe-field-readout"),
      document.querySelector<HTMLElement>(".universe-map-title"),
      document.querySelector<HTMLElement>(".universe-add-system"),
      document.querySelector<HTMLElement>(".universe-map-legend"),
      document.querySelector<HTMLElement>(".universe-map-mantra"),
    ].filter((node): node is HTMLElement => Boolean(node));
    const label = (node: HTMLElement): string => node.dataset.system
      ?? (node.className.split(" ").find(value => value.startsWith("universe-")) || node.tagName);
    const overlaps: string[] = [];
    for (let left = 0; left < elements.length; left += 1) {
      for (let right = left + 1; right < elements.length; right += 1) {
        const a = elements[left].getBoundingClientRect();
        const b = elements[right].getBoundingClientRect();
        const width = Math.max(0, Math.min(a.right, b.right) - Math.max(a.left, b.left));
        const height = Math.max(0, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top));
        if (width * height > 1) overlaps.push(`${label(elements[left])} / ${label(elements[right])}`);
      }
    }
    return overlaps;
  });
}

test("Track A owner loop persists through exact V197 controls", async ({ page }, testInfo) => {
  test.setTimeout(120_000);
  test.skip(testInfo.project.name !== "chromium-desktop", "The complete mutation journey runs once; mobile/WebKit parity has separate proof.");
  const stamp = `${Date.now()}-${Math.floor(Math.random() * 10000)}`;
  const email = `track-a-${stamp}@nur.app`;
  const password = `Track-A-${stamp}!`;
  const todayLine = `Track A check-in ${stamp}`;
  const talkLine = `Track A direct Talk ${stamp}`;
  const journalLine = `Track A journal ${stamp}`;
  const planTitle = `Track A plan ${stamp}`;
  const outcomeLine = `Track A outcome ${stamp}`;
  const researchLine = `Track A research ${stamp}`;
  const extraSystem = `Track A System ${stamp}`;

  await page.goto("/", { waitUntil: "load" });
  await expect(page.locator("#root")).toHaveCount(0);
  const entry = page.frameLocator("#nur-entry-stage");
  await entry.locator("body").evaluate(() => {
    (window as unknown as { nurShowFront?: () => void }).nurShowFront?.();
  });
  await expect(entry.locator("#f4-begin")).toBeVisible();
  await shot(page, "01-v197-landing");
  await entry.locator("#f4-begin").click();
  await entry.locator("#f4-name").fill("Track A Owner");
  await entry.locator("#f4-email").fill(email);
  await entry.locator("#f4-password").fill(password);
  await entry.locator("#f4-consent-check").check();
  await shot(page, "02-v197-real-signup");
  await entry.locator("#f4-signup-form button[type='submit']").click();

  const universe = page.frameLocator("#nur-universe-stage");
  await expect(universe.locator("#page-systems")).toBeVisible({ timeout: 20_000 });
  await expect(universe.locator(".universe-system-node:visible")).toHaveCount(7);
  await expect(universe.locator(".universe-system-node b")).toHaveText([
    "Quiet Ambition", "Rebuild", "Study", "Money", "Body", "Connection", "Creation",
  ]);
  await expect(universe.locator(".clean-system-row:visible")).toHaveText([
    "Quiet Ambition", "Rebuild", "Study", "Money", "Body", "Connection", "Creation",
  ]);
  await expect(universe.locator('[data-world-tab="map"]')).toHaveText("Map");
  await expect(universe.locator(".universe-insight-panel")).not.toContainText("78%");
  await expect(universe.locator(".universe-insight-panel")).not.toContainText("34 lived returns");
  await expect(universe.locator(`#nur-v197-track-a-premium-polish`)).toHaveCount(1);
  expect(await criticalMapOverlaps(page)).toEqual([]);
  const topbar = await universe.locator(".nur-topbar").evaluate(node => {
    const boundary = node.getBoundingClientRect();
    const nav = node.querySelector<HTMLElement>(".universe-nav-tabs");
    const tabs = nav ? [...nav.children].map(child => child.getBoundingClientRect()) : [];
    return {
      allTabsInside: tabs.every(rect => rect.left >= boundary.left && rect.right <= boundary.right),
      navScrollable: nav ? nav.scrollWidth > nav.clientWidth + 1 : true,
    };
  });
  expect(topbar).toEqual({ allTabsInside: true, navScrollable: false });
  await expect(universe.locator("#toast")).not.toHaveClass(/show/, { timeout: 7_000 });
  await shot(page, "03-v197-seven-persisted-systems");
  await universe.locator(".universe-map-panel").scrollIntoViewIfNeeded();
  await shot(page, "03b-v197-overlap-free-map-1280");

  const selectedOrbitId = await universe.locator(".universe-system-node[data-orbit-id]").nth(1).getAttribute("data-orbit-id");
  await universe.locator(".universe-system-node[data-orbit-id]").nth(1).click();
  await expect.poll(async () => page.evaluate(async () => {
    const response = await fetch("/api/v1/profile/preferences");
    return (await response.json()).active_orbit_id as string | null;
  })).toBe(selectedOrbitId);

  await universe.locator('[data-page="today"]:visible').first().click();
  await expect(universe.locator("#page-today")).toHaveClass(/active/);
  await universe.locator('[data-action="checkin"]').click();
  await expect(universe.locator("#today-input")).toBeFocused();
  await universe.locator('[data-action="show-glows"]').click();
  await expect(universe.locator('[data-context-tab="glows"]')).toHaveAttribute("aria-selected", "true");
  await universe.locator("#today-input").fill(todayLine);
  await universe.locator('[data-send="today"]').click();
  await expect(universe.locator("#page-talk")).toHaveClass(/active/, { timeout: 20_000 });
  await expect(universe.locator("#talk-stream")).toContainText(todayLine);
  await expect(universe.locator("#talk-stream")).toContainText(/not connected|not enabled|disabled/i);
  await universe.locator("#talk-input").fill(talkLine);
  await universe.locator('[data-send="talk"]').click();
  await expect(universe.locator("#talk-stream")).toContainText(talkLine, { timeout: 20_000 });
  await universe.locator('[data-thread-action="private"]').click();
  await expect(universe.locator("#toast")).toContainText(/remains private/i);
  await universe.locator('[data-thread-action="journal"]').click();
  await expect(universe.locator("#page-journal")).toHaveClass(/active/);
  await expect(universe.locator("#journal-input")).toHaveValue(talkLine);

  await universe.locator("[data-journal-prompt]").first().click();
  await expect(universe.locator("#journal-input")).not.toHaveValue("");
  await universe.locator("#journal-input").fill(journalLine);
  await universe.locator("#journal-save").click();
  await expect(universe.locator("#page-journal .journal-prompt")).toContainText(journalLine, { timeout: 20_000 });

  await universe.locator('[data-page="systems"]:visible').first().click();
  for (const mode of ["reflect", "ask", "challenge", "explore", "summarize", "plan"]) {
    const modeControl = universe.locator(`.universe-prompt-row [data-action="${mode}"]:visible`);
    await modeControl.click();
    await expect(modeControl).toHaveAttribute("aria-pressed", "true");
  }
  await universe.locator("#universe-composer-input").fill(planTitle);
  await universe.locator(".universe-send").click();
  await expect(universe.locator("#page-plan")).toHaveClass(/active/, { timeout: 20_000 });
  await expect(universe.locator("#page-plan .panel-title").first()).toHaveText(planTitle);
  await universe.locator('[data-action="make-easier"]').click();
  await expect(universe.locator(".plan-step h3").first()).toContainText("Make it smaller:", { timeout: 20_000 });
  await universe.locator(".plan-check[data-plan-step-id]").first().click();
  await expect(universe.locator(".plan-step.done")).toHaveCount(1, { timeout: 20_000 });
  await expect(universe.locator("#nur-outcome-composer")).toBeVisible();
  await universe.locator("#nur-outcome-input").fill(outcomeLine);
  await universe.locator('[data-action="return-outcome"]').click();
  await expect.poll(async () => page.evaluate(async () => {
    const response = await fetch("/api/v1/glow/summary");
    return (await response.json()).balance as number;
  }), { timeout: 20_000 }).toBeGreaterThanOrEqual(35);
  await expect(universe.locator("#page-today .panel-title").first()).toContainText("Glow Points");

  await universe.locator('[data-page="systems"]:visible').first().click();
  await universe.locator('[data-world-tab="map"]').click();
  await expect(page).toHaveURL(/\/universe\/map$/);
  await expect(universe.locator(".universe-insight-panel")).toBeVisible();
  await expect(universe.locator(".universe-insight-panel")).toContainText("persisted Systems");
  await expect(universe.locator(".universe-insight-panel")).toContainText("owner-owned orbits");
  await universe.locator('[data-world-tab="orbits"]').click();
  await expect(page).toHaveURL(/\/universe\/orbits$/);
  await expect(universe.locator(".universe-insight-panel")).toContainText("Quiet Ambition");
  await universe.locator('[data-world-tab="timeline"]').click();
  await expect(page).toHaveURL(/\/universe\/timeline$/);
  await expect(universe.locator(".universe-insight-panel")).toContainText(outcomeLine);
  await universe.locator('[data-world-tab="insights"]').click();
  await expect(page).toHaveURL(/\/universe\/insights$/);
  await expect(universe.locator(".universe-insight-panel")).toContainText("candidate claims");
  await expect(universe.locator("#toast")).not.toHaveClass(/show/, { timeout: 7_000 });
  await shot(page, "04-v197-real-insights-lens");

  await universe.locator("#scope-open").click();
  await expect(universe.locator("#nur-v197-locale")).toBeVisible();
  await universe.locator("#nur-v197-locale").selectOption("ko");
  await universe.locator("#nur-v197-language-save").click();
  await expect(universe.locator("html")).toHaveAttribute("lang", "ko");
  await expect(universe.locator('[data-page="today"] .clean-nav-title')).toHaveText("오늘");
  await shot(page, "05-v197-korean-language");

  await universe.locator("#nur-v197-locale").selectOption("ur");
  await universe.locator("#nur-v197-writing-preference").selectOption("roman");
  await universe.locator("#nur-v197-language-save").click();
  await expect(universe.locator("html")).toHaveAttribute("lang", "ur");
  await expect(universe.locator("html")).toHaveAttribute("dir", "ltr");
  await expect(universe.locator("#talk-input")).toHaveAttribute("placeholder", "Seedha bolo...");
  await expect(universe.locator('[data-world-tab="map"]')).toHaveText("Naqsha");
  await universe.locator('#scope-modal .scope-option[data-scope="Private"]').click();
  await expect.poll(async () => page.evaluate(async () => {
    const response = await fetch("/api/v1/profile/preferences");
    return (await response.json()).default_boundary as string;
  })).toBe("PRIVATE_ORBIT");
  await shot(page, "06-v197-roman-urdu-ltr");

  await page.reload({ waitUntil: "load" });
  const refreshed = page.frameLocator("#nur-universe-stage");
  await expect(refreshed.locator("#page-systems")).toBeVisible({ timeout: 20_000 });
  await expect(refreshed.locator("html")).toHaveAttribute("lang", "ur");
  await expect(refreshed.locator("html")).toHaveAttribute("dir", "ltr");
  await refreshed.locator('[data-page="journal"]:visible').first().click();
  await expect(refreshed.locator("#page-journal .journal-prompt")).toContainText(journalLine);
  await refreshed.locator('[data-page="plan"]:visible').first().click();
  await expect(refreshed.locator("#page-plan .panel-title").first()).toHaveText(planTitle);
  await refreshed.locator('[data-page="talk"]:visible').first().click();
  await expect(refreshed.locator("#talk-stream")).toContainText(todayLine);
  await refreshed.locator('[data-page="today"]:visible').first().click();
  await expect(refreshed.locator("#page-today .panel-title").first()).toContainText("Glow Points");
  await shot(page, "07-v197-persisted-after-refresh");

  const persisted = await page.evaluate(async () => {
    const [glow, plans, journal, state] = await Promise.all([
      fetch("/api/v1/glow/summary").then(response => response.json()),
      fetch("/api/v1/plans").then(response => response.json()),
      fetch("/api/v1/journal").then(response => response.json()),
      fetch("/api/v1/orbits/current-state").then(response => response.json()),
    ]);
    return { glow, plans, journal, state };
  });
  expect(persisted.glow.balance).toBeGreaterThanOrEqual(31);
  expect(persisted.plans[0].title).toBe(planTitle);
  expect(persisted.journal[0].body).toBe(journalLine);
  expect(persisted.state.active_systems).toBe(7);
  expect(persisted.state.outcomes_returned).toBe(1);

  await page.setViewportSize({ width: 1600, height: 900 });
  await refreshed.locator('[data-page="systems"]:visible').first().click();
  await expect(refreshed.locator("#universe-search")).toBeVisible();
  await refreshed.locator("#universe-search").fill(journalLine);
  await refreshed.locator("#universe-search").press("Enter");
  await expect(refreshed.locator("#universe-research .research-results")).toContainText(journalLine, { timeout: 20_000 });
  await refreshed.locator('[data-world-focus="research"]:visible').first().click();
  await refreshed.locator("#research-query").fill(researchLine);
  await refreshed.locator("[data-research-submit]").click();
  await expect(refreshed.locator("#universe-research .research-results")).toContainText(researchLine, { timeout: 20_000 });

  await refreshed.locator("#universe-composer-input").fill(extraSystem);
  await refreshed.locator('[data-action="add-system"]').click();
  await expect(refreshed.locator("#toast")).toContainText("System persisted", { timeout: 20_000 });
  await expect.poll(async () => page.evaluate(async title => {
    const response = await fetch("/api/v1/orbits");
    const orbits = await response.json() as Array<{ title: string }>;
    return orbits.some(orbit => orbit.title === title);
  }, extraSystem)).toBe(true);
  await expect(refreshed.locator(".universe-system-node:visible")).toHaveCount(7);

  await refreshed.locator('[data-page="talk"]:visible').first().click();
  const balanceBeforeReplay = await page.evaluate(async () => {
    const response = await fetch("/api/v1/glow/summary");
    return (await response.json()).balance as number;
  });
  await refreshed.locator('[data-thread-action="glow"]').click();
  await expect.poll(async () => page.evaluate(async () => {
    const response = await fetch("/api/v1/glow/summary");
    return (await response.json()).balance as number;
  })).toBe(balanceBeforeReplay);
  await refreshed.locator('[data-thread-action="plan"]').click();
  await expect(refreshed.locator("#page-plan")).toHaveClass(/active/, { timeout: 20_000 });
  await expect(refreshed.locator("#page-plan .panel-title").first()).toHaveText(talkLine);
});

test("Track A premium V197 map has no critical overlap at 1440", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "chromium-desktop", "Laptop geometry proof runs once in desktop Chromium.");
  test.setTimeout(60_000);
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto("/", { waitUntil: "load" });
  const entry = page.frameLocator("#nur-entry-stage");
  await entry.locator("body").evaluate(() => {
    (window as unknown as { nurShowFront?: () => void }).nurShowFront?.();
  });
  await entry.locator("#f4-signin").click();
  await entry.locator("#f4-signin-email").fill("owner@nur.app");
  await entry.locator("#f4-signin-password").fill("owner-demo-pass-123");
  await entry.locator("#f4-signin-form button[type='submit']").click();
  const universe = page.frameLocator("#nur-universe-stage");
  await expect(universe.locator("#page-systems")).toBeVisible({ timeout: 20_000 });
  await expect(universe.locator(".universe-system-node:visible")).toHaveCount(7);
  expect(await criticalMapOverlaps(page)).toEqual([]);
  await universe.locator(".universe-map-panel").scrollIntoViewIfNeeded();
  await expect(universe.locator("#toast")).not.toHaveClass(/show/, { timeout: 7_000 });
  await shot(page, "08-v197-overlap-free-map-1440");
});
