import { expect, test, type Route } from "@playwright/test";
import { mockUser, json } from "./helpers/nurMocks";

test.use({ serviceWorkers: "block" });

test("V197 landing restores exact hero, signup, signin, and protected entry", async ({ page }) => {
  let authenticated = false;

  await page.route("**/api/v1/auth/**", async (route: Route) => {
    const path = new URL(route.request().url()).pathname;
    if (path === "/api/v1/auth/me") {
      return authenticated ? json(route, mockUser) : json(route, { detail: "Not authenticated" }, 401);
    }
    if (path === "/api/v1/auth/register" || path === "/api/v1/auth/login") {
      authenticated = true;
      return json(route, path.endsWith("/login") ? { ok: true } : mockUser, path.endsWith("/login") ? 200 : 201);
    }
    if (path === "/api/v1/auth/logout") {
      authenticated = false;
      return json(route, undefined, 204);
    }
    return json(route, { detail: "unhandled" }, 404);
  });
  await page.route("**/api/v1/orbits", route => json(route, []));
  await page.route("**/api/v1/journal", route => json(route, []));
  await page.route("**/api/v1/plans", route => json(route, []));
  await page.route("**/api/v1/cognition/talk-thread**", route => json(route, []));
  await page.route("**/api/v1/orbits/current-state", route => json(route, {
    active_systems: 0,
    outcomes_returned: 0,
    insights_evolving: 0,
    open_questions: 0,
    research_staged: 0,
    plans_active: 0,
    live_status: "owner_ledger",
  }));

  await page.goto("/");
  await expect(page.locator(".f4-title")).toContainText("There is a universe inside your mind.");
  await expect(page.locator(".f4-title em")).toHaveText("mind.");
  const mindStyle = await page.locator(".f4-title em").evaluate(el => ({
    text: el.textContent,
    display: getComputedStyle(el).display,
    backgroundClip: getComputedStyle(el).backgroundClip,
    webkitTextFillColor: getComputedStyle(el).webkitTextFillColor,
  }));
  expect(mindStyle.text).toBe("mind.");
  expect(mindStyle.display).not.toBe("block");
  expect(mindStyle.backgroundClip).toContain("text");
  expect(mindStyle.webkitTextFillColor).toBe("rgba(0, 0, 0, 0)");
  await expect(page.locator(".f4-brand-word")).toHaveText("NUR");

  await page.getByTestId("tab-register").click();
  await expect(page.locator('[data-mode="signup"]')).toBeVisible();
  await page.locator("#f4-name").fill("Selene");
  await page.locator("#f4-email").fill("selene@nurapp.dev");
  await page.locator("#f4-password").fill("orbit-pass-2026");
  await page.getByTestId("consent").check();
  await page.locator('[data-mode="signup"] [data-testid="auth-submit"]').click();
  await page.getByRole("button", { name: "my mind" }).click();
  await page.getByRole("button", { name: /Sketch my first Orbit/ }).click();
  await page.getByRole("button", { name: "Return to the sky" }).click();
  await expect(page.locator("#page-today")).toBeVisible();

  await page.getByTestId("user-star").click();
  await page.getByTestId("logout").click();
  await expect(page.getByTestId("tab-login")).toBeVisible();

  await page.getByTestId("tab-login").click();
  await expect(page.locator('[data-mode="signin"]')).toBeVisible();
  await page.locator("#f4-signin-email").fill("selene@nurapp.dev");
  await page.locator("#f4-signin-password").fill("orbit-pass-2026");
  await page.locator('[data-mode="signin"] [data-testid="auth-submit"]').click();
  await expect(page.locator("#page-today")).toBeVisible();
});
