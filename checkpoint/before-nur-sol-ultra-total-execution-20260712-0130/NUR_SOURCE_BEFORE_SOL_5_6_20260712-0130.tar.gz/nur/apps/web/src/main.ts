import { bootstrapV197Bridge } from "./bridge/v197Bridge";

void bootstrapV197Bridge().catch(error => {
  // The bridge is intentionally nonvisual. Leave the canonical V197 entry intact
  // if a read-only API hydration cannot start.
  console.error("NUR V197 bridge did not start", error);
});
