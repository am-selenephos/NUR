import { describe, expect, it, vi } from "vitest";

import type { V197BridgeSnapshot } from "../bridge/v197ApiClient";
import { bindV197Actions, type V197ActionApi } from "../bridge/v197Bindings";

function snapshot(): V197BridgeSnapshot {
  return {
    session: {
      id: "owner",
      email: "owner@nur.app",
      profile: { chosen_name: "Owner", locale: "ur", writing_preference: "roman" },
      orbit: { id: "personal", title: "Personal Orbit", kind: "PERSONAL_BRIDGE", status: "ACTIVE" },
    },
    ownerState: null,
    map: { provenance_label: "owner_ledger", counts: [], nodes: [{ id: "system-1", title: "Quiet Ambition", kind: "PROJECT", orbit_id: "system-1", active: true, counts: {} }] },
    orbits: null,
    timeline: null,
    insights: null,
    preferences: { locale: "ur", writing_preference: "roman", active_orbit_id: "system-1", default_boundary: "PRIVATE_ORBIT" },
    talkThread: [],
    journal: [],
    plans: [],
    glow: { balance: 0, lifetime_points: 0, recent_transactions: [], streaks: [] },
    researchBriefs: [],
  };
}

function api(): Record<string, ReturnType<typeof vi.fn>> {
  return {
    event: vi.fn(),
    talk: vi.fn(),
    createJournal: vi.fn(),
    createPlan: vi.fn(),
    patchPlanStep: vi.fn(),
    createOutcome: vi.fn(),
    rewardGlow: vi.fn(),
    patchPreferences: vi.fn(),
    createResearchBrief: vi.fn(),
    createOrbit: vi.fn(),
    get: vi.fn(),
  };
}

async function settle(): Promise<void> {
  await new Promise(resolve => window.setTimeout(resolve, 0));
  await new Promise(resolve => window.setTimeout(resolve, 0));
}

describe("Track A V197 write bindings", () => {
  it("awards Journal Glow only after the journal row is persisted", async () => {
    const document = window.document.implementation.createHTMLDocument("Journal");
    document.body.innerHTML = '<textarea id="journal-input">A persisted line.</textarea><button id="journal-save">Save</button>';
    const calls: string[] = [];
    const fake = api();
    fake.createJournal.mockImplementation(async () => {
      calls.push("journal");
      return { id: "journal-1", body: "A persisted line.", orbit_id: "system-1", event_id: "event-1", created_at: "2026-07-11T10:00:00Z" };
    });
    fake.rewardGlow.mockImplementation(async () => {
      calls.push("glow");
      return { awarded_points: 4, balance: 4, lifetime_points: 4, idempotent_replay: false, streak: null };
    });
    const refresh = vi.fn().mockResolvedValue(snapshot());

    bindV197Actions(document, fake as unknown as V197ActionApi, snapshot(), refresh);
    document.querySelector<HTMLButtonElement>("#journal-save")?.click();
    await settle();

    expect(calls).toEqual(["journal", "glow"]);
    expect(fake.rewardGlow).toHaveBeenCalledWith(expect.objectContaining({
      source_id: "journal-1",
      event_type: "journal_saved",
      idempotency_key: "journal:journal-1:saved",
    }));
    expect(refresh).toHaveBeenCalledOnce();
  });

  it("passes persisted locale and Roman Urdu preference into Talk", async () => {
    const document = window.document.implementation.createHTMLDocument("Talk");
    document.body.innerHTML = '<input id="talk-input" value="Seedha jawab do"><button data-send="talk">Send</button><div id="talk-stream"></div>';
    const fake = api();
    fake.talk.mockResolvedValue({
      turn_event_id: "turn-1",
      response_event_id: "response-1",
      model_run_id: "run-1",
      provider: "disabled",
      provider_available: false,
      provider_reason: "AI not connected",
      output: { direct_response: "AI not connected", observed: [], inferred: [], hypotheses: [], uncertainty: [], next_move: "Connect AI", memory_candidates: [], source_refs: [] },
      verification: { verdict: "ALLOW" },
    });
    fake.rewardGlow.mockResolvedValue({ awarded_points: 2, balance: 2, lifetime_points: 2, idempotent_replay: false, streak: null });
    const refresh = vi.fn().mockResolvedValue(snapshot());

    bindV197Actions(document, fake as unknown as V197ActionApi, snapshot(), refresh);
    document.querySelector<HTMLButtonElement>('[data-send="talk"]')?.click();
    await settle();

    expect(fake.talk).toHaveBeenCalledWith(expect.objectContaining({
      message: "Seedha jawab do",
      locale: "ur",
      writing_preference: "roman",
      orbit_id: "system-1",
    }));
    expect(fake.rewardGlow).toHaveBeenCalledWith(expect.objectContaining({ source_id: "turn-1", event_type: "talk_meaningful" }));
  });
});
