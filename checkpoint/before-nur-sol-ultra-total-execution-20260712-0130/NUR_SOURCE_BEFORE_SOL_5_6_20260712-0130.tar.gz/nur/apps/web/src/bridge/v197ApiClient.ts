import type { V197GlowAward, V197GlowSummary } from "./v197Rewards";

export interface V197Profile {
  chosen_name?: string | null;
  locale?: string | null;
  writing_preference?: "default" | "roman" | "script";
  sound_enabled?: boolean;
  reduced_effects?: boolean;
  default_boundary?: string;
}

export interface V197Preferences extends V197Profile {
  active_orbit_id?: string | null;
  omega_enabled?: boolean;
}

export interface V197Orbit {
  id: string;
  title: string;
  kind: string;
  description?: string | null;
  status: string;
  created_at?: string;
}

export interface V197Session {
  id: string;
  email: string;
  profile: V197Profile;
  orbit: V197Orbit;
}

export interface V197OwnerState {
  active_systems: number;
  outcomes_returned: number;
  insights_evolving: number;
  open_questions: number;
  research_staged: number;
  plans_active: number;
  live_status: string;
}

export interface V197MapNode {
  id: string;
  title: string;
  kind: string;
  orbit_id: string | null;
  active: boolean;
  counts: Record<string, number>;
}

export interface V197MapSummary {
  provenance_label: string;
  counts: Array<{ key: string; label: string; count: number }>;
  nodes: V197MapNode[];
}

export interface V197OrbitsSummary {
  provenance_label: string;
  orbits: Array<V197Orbit & { counts: Record<string, number> }>;
}

export interface V197Timeline {
  provenance_label: string;
  items: Array<{
    id: string;
    kind: string;
    title: string;
    body: string;
    created_at: string;
    provenance_label: string;
    route: string;
  }>;
}

export interface V197Insights {
  provenance_label: string;
  counts: Record<string, number>;
  claims: Array<Record<string, unknown>>;
  contradictions: Array<Record<string, unknown>>;
  predictions: Array<Record<string, unknown>>;
  review_queue: Array<Record<string, unknown>>;
}

export interface V197TalkThreadRow {
  id: string;
  who: "user" | "nur";
  text: string | null;
  structured_payload: Record<string, unknown>;
  created_at: string;
}

export interface V197TalkOutput {
  direct_response: string;
  observed: string[];
  inferred: string[];
  hypotheses: string[];
  uncertainty: string[];
  next_move: string;
  memory_candidates: string[];
  source_refs: string[];
}

export interface V197TalkResult {
  turn_event_id: string;
  response_event_id: string;
  model_run_id: string;
  provider: string;
  provider_available: boolean;
  provider_reason: string | null;
  output: V197TalkOutput;
  verification: { verdict: string; schema_valid?: boolean; source_refs_valid?: boolean };
}

export interface V197JournalEntry {
  id: string;
  body: string;
  orbit_id: string | null;
  event_id: string | null;
  created_at: string;
}

export interface V197PlanStep {
  id: string;
  title: string;
  body: string | null;
  position: number;
  done: boolean;
  done_at: string | null;
  experiment_id: string | null;
}

export interface V197Plan {
  id: string;
  title: string;
  status: string;
  orbit_id: string | null;
  steps: V197PlanStep[];
}

export interface V197EventResult {
  event: {
    id: string;
    event_kind: string;
    content_text: string | null;
    structured_payload: Record<string, unknown>;
    orbit_id: string | null;
    created_at: string;
  };
}

export interface V197Outcome {
  id: string;
  observed_result: string;
  plan_step_id: string | null;
  created_at: string;
}

export interface V197ResearchBrief {
  id: string;
  question: string;
  summary: string | null;
  status: string;
  provider_status: string;
  created_at: string;
}

export interface V197BridgeSnapshot {
  session: V197Session;
  ownerState: V197OwnerState | null;
  map: V197MapSummary | null;
  orbits: V197OrbitsSummary | null;
  timeline: V197Timeline | null;
  insights: V197Insights | null;
  preferences: V197Preferences | null;
  talkThread: V197TalkThreadRow[];
  journal: V197JournalEntry[];
  plans: V197Plan[];
  glow: V197GlowSummary;
  researchBriefs: V197ResearchBrief[];
}

export class V197ApiError extends Error {
  constructor(
    message: string,
    readonly status: number,
  ) {
    super(message);
  }
}

function cookie(name: string): string | null {
  const prefix = `${name}=`;
  const row = document.cookie.split(";").map(value => value.trim()).find(value => value.startsWith(prefix));
  return row ? decodeURIComponent(row.slice(prefix.length)) : null;
}

export class V197ApiClient {
  private async request<T>(path: string, init: RequestInit = {}): Promise<T> {
    const response = await fetch(`/api/v1${path}`, {
      ...init,
      credentials: "include",
      headers: {
        accept: "application/json",
        ...(init.body ? { "content-type": "application/json" } : {}),
        ...init.headers,
      },
    });
    if (!response.ok) {
      let detail = `${path} returned ${response.status}`;
      try {
        const body = await response.json() as { detail?: string };
        if (body.detail) detail = body.detail;
      } catch {
        // Keep the status-based fallback for non-JSON failures.
      }
      throw new V197ApiError(detail, response.status);
    }
    if (response.status === 204) return undefined as T;
    return response.json() as Promise<T>;
  }

  private writeHeaders(): HeadersInit {
    const csrf = cookie("nur_csrf");
    if (!csrf) throw new V197ApiError("The local session is missing its CSRF token.", 401);
    return { "X-CSRF-Token": csrf };
  }

  get<T>(path: string): Promise<T> {
    return this.request<T>(path);
  }

  post<T>(path: string, body: unknown, csrf = true): Promise<T> {
    return this.request<T>(path, {
      method: "POST",
      headers: csrf ? this.writeHeaders() : {},
      body: JSON.stringify(body),
    });
  }

  patch<T>(path: string, body: unknown): Promise<T> {
    return this.request<T>(path, {
      method: "PATCH",
      headers: this.writeHeaders(),
      body: JSON.stringify(body),
    });
  }

  register(payload: { chosen_name: string; email: string; password: string; consent: boolean }): Promise<V197Session> {
    return this.post<V197Session>("/auth/register", payload, false);
  }

  async login(payload: { email: string; password: string }): Promise<V197Session> {
    await this.post<{ ok: boolean }>("/auth/login", payload, false);
    const session = await this.session();
    if (!session) throw new V197ApiError("The session was not established.", 401);
    return session;
  }

  async session(): Promise<V197Session | null> {
    try {
      return await this.get<V197Session>("/auth/me");
    } catch (error) {
      if (error instanceof V197ApiError && error.status === 401) return null;
      throw error;
    }
  }

  event(payload: {
    event_kind: string;
    content_text?: string;
    structured_payload?: Record<string, unknown>;
    orbit_id?: string | null;
  }): Promise<V197EventResult> {
    return this.post<V197EventResult>("/cognition/events", payload);
  }

  talk(payload: {
    message: string;
    orbit_id?: string | null;
    locale: string;
    writing_preference: string;
    mode?: string;
  }): Promise<V197TalkResult> {
    return this.post<V197TalkResult>("/cognition/talk", payload);
  }

  createJournal(body: string, orbitId: string | null): Promise<V197JournalEntry> {
    return this.post<V197JournalEntry>("/journal", { body, orbit_id: orbitId });
  }

  createPlan(title: string, orbitId: string | null): Promise<V197Plan> {
    return this.post<V197Plan>("/plans", {
      title,
      orbit_id: orbitId,
      steps: [{ title: `Make one visible move: ${title}`, position: 0 }],
    });
  }

  patchPlanStep(stepId: string, body: { done?: boolean; title?: string }): Promise<V197PlanStep> {
    return this.patch<V197PlanStep>(`/plan-steps/${encodeURIComponent(stepId)}`, body);
  }

  createOutcome(observedResult: string, stepId: string): Promise<V197Outcome> {
    return this.post<V197Outcome>("/outcomes", {
      observed_result: observedResult,
      plan_step_id: stepId,
      structured_measurements: {},
    });
  }

  rewardGlow(payload: {
    event_type: string;
    source_kind: string;
    source_id: string;
    orbit_id?: string | null;
    idempotency_key: string;
  }): Promise<V197GlowAward> {
    return this.post<V197GlowAward>("/glow/rewards", payload);
  }

  patchPreferences(payload: Partial<V197Preferences>): Promise<V197Preferences> {
    return this.patch<V197Preferences>("/profile/preferences", payload);
  }

  createResearchBrief(question: string, orbitId: string | null): Promise<V197ResearchBrief> {
    return this.post<V197ResearchBrief>("/research/briefs", { question, orbit_id: orbitId });
  }

  createOrbit(title: string): Promise<V197Orbit> {
    return this.post<V197Orbit>("/orbits", { title, kind: "PROJECT", description: "Created from the V197 Systems field." });
  }

  async snapshot(session: V197Session): Promise<V197BridgeSnapshot> {
    const read = async <T>(path: string, fallback: T): Promise<T> => {
      try {
        return await this.get<T>(path);
      } catch {
        return fallback;
      }
    };

    const emptyGlow: V197GlowSummary = { balance: 0, lifetime_points: 0, recent_transactions: [], streaks: [] };
    const [ownerState, map, orbits, timeline, insights, preferences, talkThread, journal, plans, glow, researchBriefs] = await Promise.all([
      read<V197OwnerState | null>("/orbits/current-state", null),
      read<V197MapSummary | null>("/universe/map-summary", null),
      read<V197OrbitsSummary | null>("/universe/orbits-summary", null),
      read<V197Timeline | null>("/universe/timeline", null),
      read<V197Insights | null>("/universe/insights-summary", null),
      read<V197Preferences | null>("/profile/preferences", null),
      read<V197TalkThreadRow[]>("/cognition/talk-thread", []),
      read<V197JournalEntry[]>("/journal", []),
      read<V197Plan[]>("/plans", []),
      read<V197GlowSummary>("/glow/summary", emptyGlow),
      read<V197ResearchBrief[]>("/research/briefs", []),
    ]);

    return {
      session,
      ownerState,
      map,
      orbits,
      timeline,
      insights,
      preferences,
      talkThread,
      journal,
      plans,
      glow,
      researchBriefs,
    };
  }
}
