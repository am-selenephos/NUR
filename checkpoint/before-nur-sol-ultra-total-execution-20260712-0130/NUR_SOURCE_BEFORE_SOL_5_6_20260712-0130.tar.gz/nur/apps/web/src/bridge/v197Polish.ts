export const V197_PREMIUM_POLISH_STYLE_ID = "nur-v197-track-a-premium-polish";

const V197_PREMIUM_POLISH_CSS = `
/* Track A corrective layer. Canonical V197 source bytes and runtime stay intact. */
@media (min-width: 761px) {
  body.universe-edition #page-systems .universe-map-panel > .universe-map-title {
    left: 55% !important;
    width: 130px !important;
    min-width: 0 !important;
    max-width: 130px !important;
  }

  body.universe-edition .universe-map-title .nur-holo-word {
    font-size: 48px !important;
    line-height: .86 !important;
    letter-spacing: .08em !important;
  }

  body.universe-edition .universe-map-title small {
    display: block !important;
    width: 130px !important;
    font-size: 8px !important;
    line-height: 1.1 !important;
    letter-spacing: .1em !important;
    text-align: center !important;
    text-wrap: balance !important;
    white-space: normal !important;
  }

  body.universe-edition .universe-system-node.neural {
    left: 49% !important;
    right: auto !important;
    bottom: 30% !important;
    max-width: 210px !important;
    transform: translateX(-50%) !important;
  }

  body.universe-edition .universe-map-mantra {
    bottom: 58px !important;
  }

  body.universe-edition .universe-map-legend {
    bottom: 12px !important;
  }
}

@media (min-width: 761px) and (max-width: 1519px) {
  body.universe-edition .universe-main-grid {
    grid-template-columns: minmax(0, 1fr) !important;
  }

  body.universe-edition .universe-insight-panel {
    min-height: 0 !important;
  }

  body.universe-edition .universe-top-tools > .universe-search,
  body.universe-edition .universe-top-tools > .universe-deep {
    display: none !important;
  }

  body.universe-edition .universe-top-left {
    flex: 1 1 auto !important;
    min-width: 0 !important;
  }

  body.universe-edition .universe-top-tools {
    width: auto !important;
    min-width: 0 !important;
    flex: 0 0 auto !important;
  }

  body.universe-edition .universe-nav-tabs {
    width: auto !important;
    max-width: none !important;
    overflow: visible !important;
  }
}

@media (max-width: 760px) {
  body.universe-edition .nur-topbar {
    height: 96px !important;
    min-height: 96px !important;
    padding: 7px 12px 8px !important;
    display: grid !important;
    grid-template: 38px 38px / minmax(0, 1fr) !important;
    align-content: center !important;
    gap: 4px !important;
    overflow: hidden !important;
  }

  body.universe-edition .universe-top-tools {
    grid-area: 1 / 1 !important;
    width: 100% !important;
    min-width: 0 !important;
    justify-content: flex-end !important;
  }

  body.universe-edition .universe-top-tools > .universe-search {
    display: none !important;
  }

  body.universe-edition .universe-top-tools > .universe-deep {
    width: auto !important;
    min-width: 132px !important;
    max-width: none !important;
    padding-inline: 11px !important;
  }

  body.universe-edition .universe-top-left {
    grid-area: 2 / 1 !important;
    width: 100% !important;
    min-width: 0 !important;
    overflow: hidden !important;
  }

  body.universe-edition .universe-nav-tabs {
    width: 100% !important;
    max-width: none !important;
    display: flex !important;
    justify-content: flex-start !important;
    overflow-x: auto !important;
    overflow-y: hidden !important;
    overscroll-behavior-inline: contain !important;
    scroll-snap-type: x proximity !important;
    scrollbar-width: none !important;
  }

  body.universe-edition .universe-nav-tabs::-webkit-scrollbar,
  body.universe-edition .universe-command-row::-webkit-scrollbar {
    display: none !important;
  }

  body.universe-edition .universe-nav-tabs button {
    width: auto !important;
    min-width: max-content !important;
    gap: 6px !important;
    padding-inline: 8px !important;
    flex: 0 0 auto !important;
    scroll-snap-align: start !important;
  }

  body.universe-edition .universe-nav-tabs button > span:not(.nur-exact-mini-host) {
    display: inline !important;
  }

  body.universe-edition .universe-command-row {
    display: flex !important;
    flex-wrap: nowrap !important;
    overflow-x: auto !important;
    overflow-y: hidden !important;
    overscroll-behavior-inline: contain !important;
    scroll-snap-type: x proximity !important;
    scrollbar-width: none !important;
  }

  body.universe-edition .universe-command-row .world-command {
    flex: 0 0 auto !important;
    scroll-snap-align: start !important;
  }

  body.universe-edition .universe-map-mantra {
    left: 10% !important;
    right: 10% !important;
    bottom: 52px !important;
    width: auto !important;
    transform: none !important;
    white-space: normal !important;
  }

  body.universe-edition .universe-map-legend {
    bottom: 10px !important;
    overflow-x: auto !important;
    justify-content: flex-start !important;
    scrollbar-width: none !important;
  }
}
`;

export function ensureV197PremiumPolish(document: Document): HTMLStyleElement {
  const existing = document.getElementById(V197_PREMIUM_POLISH_STYLE_ID) as HTMLStyleElement | null;
  if (existing) return existing;
  const style = document.createElement("style");
  style.id = V197_PREMIUM_POLISH_STYLE_ID;
  style.dataset.nurLayer = "v197-native-premium-polish";
  style.textContent = V197_PREMIUM_POLISH_CSS;
  document.head.append(style);
  return style;
}
