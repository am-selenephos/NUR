import {
  V197ApiClient,
  type V197BridgeSnapshot,
  type V197JournalEntry,
  type V197Plan,
  type V197PlanStep,
  type V197Session,
} from "./v197ApiClient";
import { ensureV197LanguageControls, type WritingPreference } from "./v197I18n";
import { hydrateTrackAV197 } from "./v197Hydration";
import { announcePersistedGlow } from "./v197Rewards";

export type V197ActionApi = Pick<
  V197ApiClient,
  | "event"
  | "talk"
  | "createJournal"
  | "createPlan"
  | "patchPlanStep"
  | "createOutcome"
  | "rewardGlow"
  | "patchPreferences"
  | "createResearchBrief"
  | "createOrbit"
  | "get"
>;

type RefreshSnapshot = () => Promise<V197BridgeSnapshot>;
type V197UniverseWindow = Window & {
  nurToast?: (message: string) => void;
  nurOpenPage?: (page: string, options?: Record<string, unknown>) => void;
};

function closest(target: EventTarget | null, selector: string): HTMLElement | null {
  const node = target as Element | null;
  return node && typeof node.closest === "function" ? node.closest<HTMLElement>(selector) : null;
}

function inputValue(document: Document, selector: string): string {
  return document.querySelector<HTMLInputElement | HTMLTextAreaElement>(selector)?.value.trim() ?? "";
}

function setInputValue(document: Document, selector: string, value: string): void {
  const input = document.querySelector<HTMLInputElement | HTMLTextAreaElement>(selector);
  if (input) input.value = value;
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : "The action could not be persisted.";
}

export class V197ActionBindings {
  private snapshot: V197BridgeSnapshot;
  private composerMode = "talk";
  private readonly clickHandler = (event: Event) => this.onClick(event);
  private readonly keyHandler = (event: Event) => this.onKeyDown(event as KeyboardEvent);
  private readonly scopeHandler = (event: Event) => this.onScopeChoice(event);

  constructor(
    private readonly document: Document,
    private readonly api: V197ActionApi,
    initialSnapshot: V197BridgeSnapshot,
    private readonly refreshSnapshot: RefreshSnapshot,
  ) {
    this.snapshot = initialSnapshot;
  }

  bind(): () => void {
    this.document.addEventListener("click", this.clickHandler, true);
    this.document.addEventListener("keydown", this.keyHandler, true);
    this.document.addEventListener("click", this.scopeHandler);
    this.installLanguageControls();
    return () => {
      this.document.removeEventListener("click", this.clickHandler, true);
      this.document.removeEventListener("keydown", this.keyHandler, true);
      this.document.removeEventListener("click", this.scopeHandler);
    };
  }

  private universeWindow(): V197UniverseWindow | null {
    return this.document.defaultView as V197UniverseWindow | null;
  }

  private toast(message: string): void {
    this.universeWindow()?.nurToast?.(message);
  }

  private activeOrbitId(): string | null {
    return this.snapshot.preferences?.active_orbit_id
      ?? this.snapshot.map?.nodes.find(node => node.kind !== "PERSONAL_BRIDGE")?.id
      ?? this.snapshot.session.orbit.id
      ?? null;
  }

  private locale(): string {
    return this.snapshot.preferences?.locale ?? this.snapshot.session.profile.locale ?? "en";
  }

  private writingPreference(): WritingPreference {
    return this.snapshot.preferences?.writing_preference
      ?? this.snapshot.session.profile.writing_preference
      ?? "default";
  }

  private async refresh(): Promise<void> {
    this.snapshot = await this.refreshSnapshot();
    hydrateTrackAV197(this.document, this.snapshot);
    this.installLanguageControls();
  }

  private async perform(control: HTMLElement, task: () => Promise<void>): Promise<void> {
    if (control.dataset.nurBusy === "true") return;
    control.dataset.nurBusy = "true";
    control.setAttribute("aria-busy", "true");
    try {
      await task();
    } catch (error) {
      this.toast(errorMessage(error));
    } finally {
      delete control.dataset.nurBusy;
      control.removeAttribute("aria-busy");
    }
  }

  private blockNative(event: Event): void {
    event.preventDefault();
    event.stopImmediatePropagation();
  }

  private async award(
    eventType: string,
    sourceKind: string,
    sourceId: string,
    idempotencyKey: string,
  ): Promise<void> {
    const award = await this.api.rewardGlow({
      event_type: eventType,
      source_kind: sourceKind,
      source_id: sourceId,
      orbit_id: this.activeOrbitId(),
      idempotency_key: idempotencyKey,
    });
    announcePersistedGlow(this.document, award);
  }

  private async saveJournal(): Promise<void> {
    const body = inputValue(this.document, "#journal-input");
    if (!body) {
      this.toast("Write one honest line first.");
      return;
    }
    const row: V197JournalEntry = await this.api.createJournal(body, this.activeOrbitId());
    await this.award("journal_saved", "JOURNAL_ENTRY", row.id, `journal:${row.id}:saved`);
    setInputValue(this.document, "#journal-input", "");
    await this.refresh();
    this.toast("Journal persisted privately.");
  }

  private async sendTalk(source: "talk" | "today" | "mobile" | "composer"): Promise<void> {
    const inputSelector = source === "today"
      ? "#today-input"
      : source === "mobile"
        ? "#mobile-composer"
        : source === "composer"
          ? "#universe-composer-input"
          : "#talk-input";
    const message = inputValue(this.document, inputSelector);
    if (!message) {
      this.toast("Give NUR one real sentence.");
      return;
    }

    if (source === "today") {
      const checkin = await this.api.event({
        event_kind: "SYSTEM_EVENT",
        content_text: message,
        structured_payload: { type: "today_checkin", provenance_label: "OWNER_WRITTEN" },
        orbit_id: this.activeOrbitId(),
      });
      await this.award("daily_checkin", "COGNITIVE_EVENT", checkin.event.id, `today:${checkin.event.id}:checkin`);
    }

    const result = await this.api.talk({
      message,
      orbit_id: this.activeOrbitId(),
      locale: this.locale(),
      writing_preference: this.writingPreference(),
      mode: this.composerMode,
    });
    await this.award("talk_meaningful", "COGNITIVE_EVENT", result.turn_event_id, `talk:${result.turn_event_id}:meaningful`);
    setInputValue(this.document, inputSelector, "");
    await this.refresh();
    this.universeWindow()?.nurOpenPage?.("talk");
    this.toast(result.provider_available ? "NUR answered and persisted this turn." : result.provider_reason || "AI is not connected; the honest disabled response was persisted.");
  }

  private async createPlan(titleOverride?: string): Promise<void> {
    const title = titleOverride?.trim() || inputValue(this.document, "#universe-composer-input") || this.lastUserTalk();
    if (!title) {
      this.toast("Name one honest direction before creating a Plan.");
      this.document.querySelector<HTMLInputElement>("#universe-composer-input")?.focus();
      return;
    }
    const plan: V197Plan = await this.api.createPlan(title, this.activeOrbitId());
    await this.award("plan_created", "PLAN", plan.id, `plan:${plan.id}:created`);
    setInputValue(this.document, "#universe-composer-input", "");
    await this.refresh();
    this.universeWindow()?.nurOpenPage?.("plan");
    this.toast("Plan persisted with its first move.");
  }

  private async togglePlanStep(control: HTMLElement): Promise<void> {
    const stepId = control.dataset.planStepId;
    if (!stepId) return;
    const done = control.getAttribute("aria-pressed") !== "true";
    const step: V197PlanStep = await this.api.patchPlanStep(stepId, { done });
    if (done) await this.award("plan_step_completed", "PLAN_STEP", step.id, `plan-step:${step.id}:completed`);
    await this.refresh();
    this.toast(done ? "Step completed and persisted." : "Step reopened.");
  }

  private async makeEasier(): Promise<void> {
    const step = this.snapshot.plans[0]?.steps.find(row => !row.done);
    if (!step) {
      this.toast("There is no open persisted step to make smaller.");
      return;
    }
    const title = step.title.startsWith("Make it smaller:") ? step.title : `Make it smaller: ${step.title}`;
    const updated = await this.api.patchPlanStep(step.id, { title });
    await this.award("task_made_smaller", "PLAN_STEP", updated.id, `plan-step:${updated.id}:made-smaller`);
    await this.refresh();
    this.toast("The move is smaller and persisted.");
  }

  private async returnOutcome(): Promise<void> {
    const composer = this.document.querySelector<HTMLElement>("#nur-outcome-composer");
    const stepId = composer?.dataset.planStepId;
    const result = inputValue(this.document, "#nur-outcome-input");
    if (!stepId || !result) {
      this.toast("Complete one Plan step, then name what changed.");
      return;
    }
    const outcome = await this.api.createOutcome(result, stepId);
    await this.award("outcome_returned", "OUTCOME", outcome.id, `outcome:${outcome.id}:returned`);
    setInputValue(this.document, "#nur-outcome-input", "");
    await this.refresh();
    this.toast("Outcome returned. The ledger and Glow balance moved together.");
  }

  private async createSystem(): Promise<void> {
    const title = inputValue(this.document, "#universe-composer-input");
    if (!title) {
      this.toast("Name the System in the lower composer, then choose Add system again.");
      this.document.querySelector<HTMLInputElement>("#universe-composer-input")?.focus();
      return;
    }
    await this.api.createOrbit(title);
    setInputValue(this.document, "#universe-composer-input", "");
    await this.refresh();
    this.toast("System persisted in your private universe.");
  }

  private async stageResearch(): Promise<void> {
    const question = inputValue(this.document, "#research-query") || inputValue(this.document, "#universe-search");
    if (!question) {
      this.toast("Name a research question first.");
      return;
    }
    await this.api.createResearchBrief(question, this.activeOrbitId());
    setInputValue(this.document, "#research-query", "");
    await this.refresh();
    this.toast("Research question saved locally. No source was invented.");
  }

  private async searchOwnerLedger(): Promise<void> {
    const query = inputValue(this.document, "#universe-search");
    if (query.length < 2) {
      this.toast("Use at least two characters to search your owner ledger.");
      return;
    }
    const hits = await this.api.get<Array<{ label: string; excerpt: string | null; kind: string }>>(`/universe/search?q=${encodeURIComponent(query)}`);
    const results = this.document.querySelector<HTMLElement>("#universe-research .research-results");
    if (results) {
      while (results.firstChild) results.removeChild(results.firstChild);
      if (hits.length === 0) {
        const row = this.document.createElement("article");
        row.textContent = "No matching owner-ledger results.";
        results.append(row);
      }
      hits.slice(0, 6).forEach(hit => {
        const row = this.document.createElement("article");
        const mark = this.document.createElement("i");
        mark.textContent = "⌕";
        const copy = this.document.createElement("div");
        const title = this.document.createElement("b");
        title.textContent = hit.label;
        const body = this.document.createElement("span");
        body.textContent = hit.excerpt || hit.kind;
        copy.append(title, body);
        row.append(mark, copy);
        results.append(row);
      });
    }
    this.toast(`${hits.length} private ledger ${hits.length === 1 ? "result" : "results"}.`);
  }

  private lastUserTalk(): string {
    return [...this.snapshot.talkThread].reverse().find(row => row.who === "user" && row.text)?.text?.trim() ?? "";
  }

  private setComposerMode(control: HTMLElement, mode: string): void {
    this.composerMode = mode === "ask" ? "talk" : mode;
    this.document.querySelectorAll<HTMLElement>(".universe-prompt-row [data-action]").forEach(button => {
      button.classList.toggle("active", button === control);
      button.setAttribute("aria-pressed", String(button === control));
    });
    this.toast(mode === "plan" ? "Plan mode selected. Send one direction." : `${mode} mode selected.`);
  }

  private selectSystem(control: HTMLElement): void {
    const orbitId = control.dataset.orbitId;
    const system = control.dataset.system;
    if (!orbitId || !system) return;
    this.document.querySelectorAll<HTMLElement>("[data-system]").forEach(node => {
      const active = node.dataset.orbitId === orbitId;
      node.classList.toggle("active", active);
      node.setAttribute("aria-pressed", String(active));
    });
    this.document.body.dataset.nurSystem = system;
    void this.perform(control, async () => {
      await this.api.patchPreferences({ active_orbit_id: orbitId });
      this.snapshot.preferences = { ...(this.snapshot.preferences ?? {}), active_orbit_id: orbitId };
      this.toast(`${system} is now the active persisted System.`);
    });
  }

  private installLanguageControls(): void {
    ensureV197LanguageControls(
      this.document,
      this.locale(),
      this.writingPreference(),
      async (locale, writingPreference) => {
        await this.api.patchPreferences({ locale, writing_preference: writingPreference });
        this.snapshot.preferences = { ...(this.snapshot.preferences ?? {}), locale, writing_preference: writingPreference };
        this.toast("Language preference persisted privately.");
      },
    );
  }

  private onScopeChoice(event: Event): void {
    const option = closest(event.target, ".scope-option[data-scope], .v172-scope-option[data-scope]");
    if (!option) return;
    const map: Record<string, string> = {
      Ephemeral: "EPHEMERAL",
      Private: "PRIVATE_ORBIT",
      "System Shared": "SYSTEM_SHARED",
      "Learning Candidate": "LEARNING_CANDIDATE",
    };
    const boundary = map[option.dataset.scope ?? ""];
    if (!boundary) return;
    void this.perform(option, async () => {
      await this.api.patchPreferences({ default_boundary: boundary });
      this.snapshot.preferences = { ...(this.snapshot.preferences ?? {}), default_boundary: boundary };
      this.toast("Boundary persisted privately.");
    });
  }

  private onClick(event: Event): void {
    const disabled = closest(event.target, "[aria-disabled=\"true\"], button:disabled");
    if (disabled) {
      this.blockNative(event);
      this.toast(disabled.getAttribute("title") || "This control is honestly unavailable in Track A.");
      return;
    }

    const system = closest(event.target, ".universe-system-node[data-orbit-id], .clean-system-row[data-orbit-id]");
    if (system) {
      this.blockNative(event);
      this.selectSystem(system);
      return;
    }

    const journal = closest(event.target, "#journal-save");
    if (journal) {
      this.blockNative(event);
      void this.perform(journal, () => this.saveJournal());
      return;
    }

    const send = closest(event.target, "[data-send], .universe-send");
    if (send) {
      this.blockNative(event);
      const source = send.classList.contains("universe-send") ? "composer" : (send.dataset.send as "talk" | "today" | "mobile");
      void this.perform(send, () => this.composerMode === "plan" && source === "composer" ? this.createPlan() : this.sendTalk(source));
      return;
    }

    const step = closest(event.target, ".plan-check[data-plan-step-id]");
    if (step) {
      this.blockNative(event);
      void this.perform(step, () => this.togglePlanStep(step));
      return;
    }

    const research = closest(event.target, "[data-research-submit]");
    if (research) {
      this.blockNative(event);
      void this.perform(research, () => this.stageResearch());
      return;
    }

    const thread = closest(event.target, "[data-thread-action]");
    if (thread) {
      this.blockNative(event);
      const action = thread.dataset.threadAction;
      if (action === "journal") {
        setInputValue(this.document, "#journal-input", this.lastUserTalk());
        this.universeWindow()?.nurOpenPage?.("journal");
        this.toast("Latest persisted Talk moved into a Journal draft.");
      } else if (action === "plan") {
        void this.perform(thread, () => this.createPlan(this.lastUserTalk()));
      } else if (action === "glow") {
        const row = [...this.snapshot.talkThread].reverse().find(item => item.who === "user");
        if (!row) this.toast("There is no persisted Talk turn to Glow yet.");
        else void this.perform(thread, async () => {
          await this.award("talk_meaningful", "COGNITIVE_EVENT", row.id, `talk:${row.id}:meaningful`);
          await this.refresh();
        });
      } else {
        this.toast("This persisted thread remains private.");
      }
      return;
    }

    const action = closest(event.target, "[data-action]");
    if (!action) return;
    const name = action.dataset.action ?? "";
    if (["reflect", "ask", "challenge", "explore", "summarize", "plan"].includes(name)) {
      this.blockNative(event);
      this.setComposerMode(action, name);
      return;
    }
    if (name === "checkin") {
      this.blockNative(event);
      this.document.querySelector<HTMLInputElement>("#today-input")?.focus();
      this.toast("Name what is real; Send will persist the check-in.");
      return;
    }
    if (name === "show-glows") {
      this.blockNative(event);
      this.document.querySelector<HTMLElement>('[data-context-tab="glows"]')?.click();
      return;
    }
    if (name === "make-easier") {
      this.blockNative(event);
      void this.perform(action, () => this.makeEasier());
      return;
    }
    if (name === "return-outcome") {
      this.blockNative(event);
      void this.perform(action, () => this.returnOutcome());
      return;
    }
    if (name === "add-system") {
      this.blockNative(event);
      void this.perform(action, () => this.createSystem());
      return;
    }
    this.blockNative(event);
    this.toast("This control is honestly unavailable in the Track A vertical slice.");
  }

  private onKeyDown(event: KeyboardEvent): void {
    if (event.key !== "Enter" || event.shiftKey) return;
    const target = event.target as Element | null;
    if (!target || typeof target.matches !== "function") return;
    if (target.matches("#talk-input, #today-input, #mobile-composer, #universe-composer-input")) {
      this.blockNative(event);
      const source = target.matches("#today-input") ? "today" : target.matches("#mobile-composer") ? "mobile" : target.matches("#universe-composer-input") ? "composer" : "talk";
      void this.perform(target as HTMLElement, () => this.composerMode === "plan" && source === "composer" ? this.createPlan() : this.sendTalk(source));
      return;
    }
    if (target.matches("#research-query")) {
      this.blockNative(event);
      void this.perform(target as HTMLElement, () => this.stageResearch());
      return;
    }
    if (target.matches("#universe-search")) {
      this.blockNative(event);
      void this.perform(target as HTMLElement, () => this.searchOwnerLedger());
      return;
    }
    if (target.matches("#nur-outcome-input")) {
      this.blockNative(event);
      void this.perform(target as HTMLElement, () => this.returnOutcome());
    }
  }
}

export function bindV197Actions(
  document: Document,
  api: V197ActionApi,
  snapshot: V197BridgeSnapshot,
  refresh: RefreshSnapshot,
): () => void {
  return new V197ActionBindings(document, api, snapshot, refresh).bind();
}

export function bindV197EntryAuth(
  document: Document,
  api: Pick<V197ApiClient, "register" | "login">,
  onAuthenticated: (session: V197Session) => Promise<void>,
): () => void {
  const handler = (event: Event) => {
    const form = event.target as HTMLFormElement | null;
    if (!form || !["f4-signup-form", "f4-signin-form"].includes(form.id)) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (!form.checkValidity()) {
      form.reportValidity();
      return;
    }
    const status = document.querySelector<HTMLElement>("#f4-status");
    const submit = form.querySelector<HTMLElement>('button[type="submit"]');
    submit?.setAttribute("aria-busy", "true");
    if (status) status.textContent = form.id === "f4-signup-form" ? "Creating your private Orbit…" : "Returning to your Orbit…";

    const task = form.id === "f4-signup-form"
      ? api.register({
          chosen_name: inputValue(document, "#f4-name"),
          email: inputValue(document, "#f4-email"),
          password: inputValue(document, "#f4-password"),
          consent: document.querySelector<HTMLInputElement>("#f4-consent-check")?.checked === true,
        })
      : api.login({
          email: inputValue(document, "#f4-signin-email"),
          password: inputValue(document, "#f4-signin-password"),
        });

    void task.then(onAuthenticated).catch(error => {
      if (status) status.textContent = errorMessage(error);
    }).finally(() => submit?.removeAttribute("aria-busy"));
  };
  document.addEventListener("submit", handler, true);
  return () => document.removeEventListener("submit", handler, true);
}
