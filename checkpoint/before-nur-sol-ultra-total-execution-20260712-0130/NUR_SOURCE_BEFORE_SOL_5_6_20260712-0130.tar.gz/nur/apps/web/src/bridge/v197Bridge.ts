import { V197ApiClient, type V197BridgeSnapshot, type V197Session } from "./v197ApiClient";
import { bindV197Actions, bindV197EntryAuth } from "./v197Bindings";
import { emitBridgeEvent, routeForPage, routeForWorldFocus, V197_EVENTS, type V197NativeRoute } from "./v197Events";
import { hydrateTrackAV197, renderWorldLens } from "./v197Hydration";
import { ensureV197PremiumPolish } from "./v197Polish";
import { selectRequired, V197_SELECTORS } from "./v197Selectors";

type V197HostApi = {
  verifySources: () => Promise<{ pass: boolean }>;
  completeSignIn: (profile: Record<string, unknown>) => void;
  showEntry: () => void;
};

type V197HostWindow = Window & { NURConsolidated?: V197HostApi };
type V197UniverseWindow = Window & { nurToast?: (message: string) => void };

declare global {
  interface Window {
    __NUR_V197_BRIDGE__?: V197Bridge;
  }
}

function nativeRoute(pathname: string): V197NativeRoute {
  const value = pathname.replace(/\/+$/, "") || "/";
  return value as V197NativeRoute;
}

function pause(milliseconds: number): Promise<void> {
  return new Promise(resolve => window.setTimeout(resolve, milliseconds));
}

async function waitForFrameDocument(frame: HTMLIFrameElement, requiredSelector: string, label: string): Promise<Document> {
  const deadline = Date.now() + 10_000;
  while (Date.now() < deadline) {
    const document = frame.contentDocument;
    if (document?.readyState === "complete" && document.querySelector(requiredSelector)) return document;
    await pause(25);
  }
  throw new Error(`${label} did not initialize.`);
}

export class V197Bridge {
  private readonly api = new V197ApiClient();
  private applyingRoute = false;
  private universeDocument: Document | null = null;
  private snapshot: V197BridgeSnapshot | null = null;
  private actionCleanup: (() => void) | null = null;

  constructor(
    private readonly hostWindow: V197HostWindow,
    private readonly hostDocument: Document,
  ) {}

  async start(): Promise<void> {
    const hostApi = this.hostWindow.NURConsolidated;
    if (!hostApi) throw new Error("Canonical V197 host did not initialize.");

    const integrity = await hostApi.verifySources();
    if (!integrity.pass) throw new Error("Canonical V197 source verification failed.");
    const entryFrame = selectRequired<HTMLIFrameElement>(this.hostDocument, V197_SELECTORS.entryStage);
    const entryDocument = await waitForFrameDocument(entryFrame, "#nur-front-v61", "Canonical V197 entry");

    window.addEventListener("popstate", () => void this.applyCurrentRoute());
    emitBridgeEvent(V197_EVENTS.ready, { integrity: "pass", mode: "track-a-persisted" });

    const session = await this.api.session();
    if (session) {
      await this.activateSession(hostApi, session);
      return;
    }

    bindV197EntryAuth(entryDocument, this.api, async authenticated => {
      await this.activateSession(hostApi, authenticated);
    });
  }

  async applyCurrentRoute(): Promise<void> {
    if (!this.universeDocument) return;
    const route = nativeRoute(window.location.pathname);
    const pageByRoute: Partial<Record<V197NativeRoute, string>> = {
      "/today": "today",
      "/talk": "talk",
      "/journal": "journal",
      "/plan": "plan",
      "/systems": "systems",
      "/universe": "systems",
    };
    const worldByRoute: Partial<Record<V197NativeRoute, string>> = {
      "/systems": "universe",
      "/universe": "universe",
      "/universe/map": "map",
      "/universe/orbits": "orbits",
      "/universe/timeline": "timeline",
      "/universe/insights": "insights",
      "/universe/research": "research",
      "/universe/community": "community",
      "/universe/web-signals": "web",
    };

    this.applyingRoute = true;
    try {
      const page = pageByRoute[route];
      if (page) this.click(V197_SELECTORS.pageNav(page));
      const world = worldByRoute[route];
      if (world && world !== "universe") this.click(V197_SELECTORS.worldFocus(world));
      if (world && this.snapshot) renderWorldLens(this.universeDocument, this.snapshot, world);
    } finally {
      this.applyingRoute = false;
    }
  }

  private async activateSession(hostApi: V197HostApi, session: V197Session): Promise<void> {
    const universeDocument = await this.enterAuthenticatedUniverse(hostApi, this.hostDocument, session);
    this.universeDocument = universeDocument;
    ensureV197PremiumPolish(universeDocument);
    this.snapshot = await this.api.snapshot(session);
    this.bindNativeNavigation(universeDocument);
    await this.applyCurrentRoute();
    hydrateTrackAV197(universeDocument, this.snapshot);

    this.actionCleanup?.();
    this.actionCleanup = bindV197Actions(
      universeDocument,
      this.api,
      this.snapshot,
      async () => {
        const currentSession = await this.api.session();
        if (!currentSession) throw new Error("Your local Orbit session ended. Sign in again.");
        const next = await this.api.snapshot(currentSession);
        this.snapshot = next;
        return next;
      },
    );
    emitBridgeEvent(V197_EVENTS.sessionHydrate, this.snapshotEventDetail(this.snapshot));
  }

  private async enterAuthenticatedUniverse(hostApi: V197HostApi, hostDocument: Document, session: V197Session): Promise<Document> {
    const universeFrame = selectRequired<HTMLIFrameElement>(hostDocument, V197_SELECTORS.universeStage);
    hostApi.completeSignIn({
      email: session.email,
      chosen_name: session.profile.chosen_name ?? "",
      locale: session.profile.locale ?? "en",
      source: "track-a-persisted-bridge",
    });
    return waitForFrameDocument(universeFrame, "#page-systems", "Canonical V197 universe frame");
  }

  private bindNativeNavigation(universeDocument: Document): void {
    const universeWindow = universeDocument.defaultView as V197UniverseWindow | null;
    if (!universeWindow || universeDocument.documentElement.dataset.nurTrackANavigation === "bound") return;
    universeDocument.documentElement.dataset.nurTrackANavigation = "bound";

    universeDocument.addEventListener("click", event => {
      const target = event.target as Element | null;
      if (this.applyingRoute || !target || typeof target.closest !== "function") return;
      const control = target.closest<HTMLElement>("[data-page], [data-world-focus], [data-world-tab]");
      if (!control) return;
      const world = control.dataset.worldFocus ?? control.dataset.worldTab;
      const route = routeForPage(control.dataset.page ?? "") ?? routeForWorldFocus(world ?? "");
      if (!route) return;
      window.setTimeout(() => {
        this.pushRoute(route);
        if (world && this.snapshot) renderWorldLens(universeDocument, this.snapshot, world);
      }, 0);
    });

    universeWindow.addEventListener("nur:page-change", event => {
      if (this.applyingRoute) return;
      const route = routeForPage((event as CustomEvent<{ page?: string }>).detail?.page ?? "");
      if (route) this.pushRoute(route);
    });
    universeWindow.addEventListener("nur:world-focus", event => {
      if (this.applyingRoute) return;
      const focus = (event as CustomEvent<{ focus?: string }>).detail?.focus ?? "";
      const route = routeForWorldFocus(focus);
      if (route) this.pushRoute(route);
      if (this.snapshot) renderWorldLens(universeDocument, this.snapshot, focus);
    });
  }

  private click(selector: string): void {
    const button = this.universeDocument?.querySelector<HTMLElement>(selector);
    button?.click();
  }

  private pushRoute(route: V197NativeRoute): void {
    if (window.location.pathname === route) return;
    window.history.pushState({}, "", route);
  }

  private snapshotEventDetail(snapshot: V197BridgeSnapshot): Record<string, unknown> {
    return {
      authenticated: true,
      hasMap: snapshot.map !== null,
      hasOrbits: snapshot.orbits !== null,
      hasTimeline: snapshot.timeline !== null,
      hasInsights: snapshot.insights !== null,
      glowBalance: snapshot.glow.balance,
      locale: snapshot.preferences?.locale ?? snapshot.session.profile.locale ?? "en",
      mode: "track-a-persisted",
    };
  }
}

export async function bootstrapV197Bridge(): Promise<V197Bridge> {
  if (window.__NUR_V197_BRIDGE__) return window.__NUR_V197_BRIDGE__;
  selectRequired<HTMLIFrameElement>(document, V197_SELECTORS.entryStage);
  selectRequired<HTMLIFrameElement>(document, V197_SELECTORS.universeStage);
  const bridge = new V197Bridge(window as V197HostWindow, document);
  window.__NUR_V197_BRIDGE__ = bridge;
  await bridge.start();
  return bridge;
}
