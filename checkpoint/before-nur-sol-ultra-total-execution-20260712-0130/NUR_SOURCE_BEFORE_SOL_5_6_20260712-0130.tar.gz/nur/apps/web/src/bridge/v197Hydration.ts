import type {
  V197BridgeSnapshot,
  V197MapNode,
  V197Plan,
  V197PlanStep,
  V197TalkThreadRow,
} from "./v197ApiClient";
import { applyV197Locale } from "./v197I18n";
import { hydrateReadOnlyV197 } from "./v197Mutations";
import { renderPersistedGlow } from "./v197Rewards";

const CORE_SYSTEMS = [
  "Quiet Ambition",
  "Rebuild",
  "Study",
  "Money",
  "Body",
  "Connection",
  "Creation",
] as const;

function empty(node: Element): void {
  while (node.firstChild) node.removeChild(node.firstChild);
}

function text(node: Element | null, value: string): void {
  if (node) node.textContent = value;
}

function ownText(node: Element | null, value: string): void {
  if (!node) return;
  const textNodes = [...node.childNodes].filter(child => child.nodeType === 3);
  const rendered = node.firstElementChild ? ` ${value}` : value;
  if (textNodes.length === 0) {
    node.append(node.ownerDocument.createTextNode(rendered));
    return;
  }
  textNodes[0].nodeValue = rendered;
  textNodes.slice(1).forEach(child => child.remove());
}

function shorten(value: string, max = 110): string {
  const normalized = value.trim().replace(/\s+/g, " ");
  return normalized.length > max ? `${normalized.slice(0, max - 1)}…` : normalized;
}

function number(value: unknown): string {
  return typeof value === "number" && Number.isFinite(value) ? String(value) : "0";
}

function renderTalk(document: Document, rows: V197TalkThreadRow[]): void {
  const stream = document.querySelector<HTMLElement>("#talk-stream");
  if (!stream) return;
  empty(stream);

  if (rows.length === 0) {
    const message = document.createElement("div");
    message.className = "talk-message nur";
    const meta = document.createElement("div");
    meta.className = "talk-meta";
    meta.textContent = "NUR · private ledger";
    message.append(meta, document.createTextNode("No persisted Talk turns yet. Say one true line to begin."));
    stream.append(message);
    return;
  }

  rows.forEach(row => {
    const message = document.createElement("div");
    message.className = `talk-message ${row.who === "nur" ? "nur" : "user"}`;
    message.dataset.eventId = row.id;
    if (row.who === "nur") {
      const meta = document.createElement("div");
      meta.className = "talk-meta";
      meta.textContent = "NUR · model-generated";
      message.append(meta);
    }
    message.append(document.createTextNode(row.text || "Persisted response without display text."));
    stream.append(message);
  });
  stream.scrollTop = stream.scrollHeight;
}

function renderJournal(document: Document, snapshot: V197BridgeSnapshot): void {
  const count = snapshot.journal.length;
  const latest = snapshot.journal[0];
  text(
    document.querySelector("#page-journal .page-sub"),
    count === 0
      ? "Private by default. No persisted entries yet."
      : `${count} private ${count === 1 ? "entry" : "entries"} persisted in your owner ledger.`,
  );
  text(
    document.querySelector("#page-journal .journal-prompt"),
    latest ? `Last held: “${shorten(latest.body, 150)}”` : "What are you trying not to lose?",
  );
}

function makeStep(document: Document, plan: V197Plan, step: V197PlanStep): HTMLElement {
  const row = document.createElement("div");
  row.className = `plan-step${step.done ? " done" : ""}`;
  row.dataset.planId = plan.id;

  const button = document.createElement("button");
  button.type = "button";
  button.className = "plan-check nur-v136-v89-mini-host";
  button.dataset.planStepId = step.id;
  button.setAttribute("aria-label", step.done ? "Reopen step" : "Complete step");
  button.setAttribute("aria-pressed", String(step.done));

  const copy = document.createElement("div");
  const title = document.createElement("h3");
  title.textContent = step.title;
  const body = document.createElement("p");
  body.textContent = step.body || "One persisted movement inside this Plan.";
  copy.append(title, body);

  const state = document.createElement("time");
  state.textContent = step.done ? "returned" : "open";
  row.append(button, copy, state);
  return row;
}

function ensureOutcomeComposer(document: Document): void {
  if (document.querySelector("#nur-outcome-composer")) return;
  const page = document.querySelector<HTMLElement>("#page-plan article.nur-panel, #page-plan .nur-panel");
  if (!page) return;
  const shell = document.createElement("div");
  shell.id = "nur-outcome-composer";
  shell.className = "thought-composer";
  shell.hidden = true;

  const input = document.createElement("input");
  input.id = "nur-outcome-input";
  input.autocomplete = "off";
  input.placeholder = "What changed in the real world?";
  const button = document.createElement("button");
  button.type = "button";
  button.className = "thought-send-button send-holo-pill";
  button.dataset.action = "return-outcome";
  button.textContent = "Return outcome →";
  shell.append(input, button);
  page.append(shell);
}

function renderPlans(document: Document, plans: V197Plan[]): void {
  const current = plans[0];
  const list = document.querySelector<HTMLElement>("#page-plan .plan-list");
  text(document.querySelector("#page-plan .panel-title"), current?.title ?? "No persisted Plan yet");
  text(
    document.querySelector("#page-plan .panel-sub"),
    current ? `${current.steps.length} persisted ${current.steps.length === 1 ? "step" : "steps"} · ${current.status.toLowerCase()}` : "Use the composer below to name one honest direction.",
  );
  if (list) {
    empty(list);
    if (current?.steps.length) current.steps.forEach(step => list.append(makeStep(document, current, step)));
    else {
      const state = document.createElement("div");
      state.className = "plan-step";
      const copy = document.createElement("div");
      const title = document.createElement("h3");
      title.textContent = "A Plan begins after one direction is persisted.";
      copy.append(title);
      state.append(copy);
      list.append(state);
    }
  }
  ensureOutcomeComposer(document);
  const completedStep = current?.steps.find(step => step.done);
  const outcomeComposer = document.querySelector<HTMLElement>("#nur-outcome-composer");
  if (outcomeComposer) {
    outcomeComposer.hidden = !completedStep;
    if (completedStep) outcomeComposer.dataset.planStepId = completedStep.id;
    else delete outcomeComposer.dataset.planStepId;
  }
}

function systemNodes(snapshot: V197BridgeSnapshot): V197MapNode[] {
  const available = (snapshot.map?.nodes ?? []).filter(node => node.kind !== "PERSONAL_BRIDGE");
  return CORE_SYSTEMS.map(title => available.find(node => node.title === title)).filter((node): node is V197MapNode => Boolean(node));
}

function renderSystemRail(document: Document, nodes: V197MapNode[], activeOrbitId: string | null): void {
  const list = document.querySelector<HTMLElement>(".clean-system-list");
  if (!list) return;
  const existing = [...list.querySelectorAll<HTMLButtonElement>(".clean-system-row")];
  while (existing.length < nodes.length) {
    const row = document.createElement("button");
    row.type = "button";
    row.className = "clean-system-row";
    const glyph = document.createElement("i");
    glyph.textContent = "✦";
    const label = document.createElement("span");
    row.append(glyph, label);
    list.append(row);
    existing.push(row);
  }
  existing.forEach((row, index) => {
    const node = nodes[index];
    if (!node) {
      row.hidden = true;
      return;
    }
    row.hidden = false;
    row.dataset.system = node.title;
    row.dataset.orbitId = node.id;
    row.dataset.page = "systems";
    text(row.querySelector(":scope > span:not(.nur-exact-mini-host)"), node.title);
    const active = node.id === activeOrbitId || (!activeOrbitId && index === 0);
    row.classList.toggle("active", active);
    row.setAttribute("aria-pressed", String(active));
  });
}

function renderSystems(document: Document, snapshot: V197BridgeSnapshot): void {
  const nodes = systemNodes(snapshot);
  const activeOrbitId = snapshot.preferences?.active_orbit_id ?? nodes[0]?.id ?? null;
  const slots = [...document.querySelectorAll<HTMLButtonElement>(".universe-system-node")];
  slots.forEach((slot, index) => {
    const node = nodes[index];
    if (!node) {
      slot.hidden = true;
      return;
    }
    slot.hidden = false;
    slot.dataset.system = node.title;
    slot.dataset.orbitId = node.id;
    text(slot.querySelector(":scope > span:not(.nur-exact-mini-host) > b"), node.title);
    const total = Object.values(node.counts).reduce((sum, value) => sum + value, 0);
    text(slot.querySelector(":scope > span:not(.nur-exact-mini-host) > small"), `${node.kind.toLowerCase()} · ${total} held`);
    const active = node.id === activeOrbitId || (!activeOrbitId && index === 0);
    slot.classList.toggle("active", active);
    slot.setAttribute("aria-pressed", String(active));
  });
  renderSystemRail(document, nodes, activeOrbitId);

  const stateCards = [...document.querySelectorAll<HTMLElement>(".universe-state-strip > article")];
  const state = snapshot.ownerState;
  const facts: Array<[string, string, string]> = [
    ["Systems", number(state?.active_systems), "owner-owned"],
    ["Plans", number(state?.plans_active), "persisted"],
    ["Outcomes", number(state?.outcomes_returned), "returned"],
    ["Questions", number(state?.open_questions), "open"],
    ["Research", number(state?.research_staged), "saved locally"],
    ["Insights", number(state?.insights_evolving), "owner review"],
  ];
  stateCards.forEach((card, index) => {
    const fact = facts[index];
    if (!fact) return;
    text(card.querySelector("small"), fact[0]);
    text(card.querySelector("b"), fact[1]);
    text(card.querySelector("em, span"), fact[2]);
  });
}

function setLaneCard(card: Element | undefined, eyebrow: string, title: string, detail: string): void {
  if (!card) return;
  text(card.querySelector("small"), eyebrow);
  text(card.querySelector("b"), title);
  text(card.querySelector("span"), detail);
}

function renderVisibleLens(
  document: Document,
  snapshot: V197BridgeSnapshot,
  focus: string,
): void {
  if (!["map", "orbits", "timeline", "insights"].includes(focus)) return;
  const panel = document.querySelector<HTMLElement>(".universe-insight-panel");
  if (!panel) return;
  panel.dataset.nurLens = focus;
  ownText(panel.querySelector(".system-badge"), `${focus[0].toUpperCase()}${focus.slice(1)} lens`);
  text(panel.querySelector(".live-label"), "OWNER LEDGER");

  let title = "No persisted data yet";
  let copy = "This lens will not invent content before owner-scoped records exist.";
  let uncertainty = "Only persisted owner records are shown.";
  let count = 0;
  const signals: string[] = [];

  if (focus === "map") {
    const nodes = snapshot.map?.nodes.filter(node => node.kind !== "PERSONAL_BRIDGE") ?? [];
    count = nodes.length;
    title = `${count} persisted Systems`;
    copy = (snapshot.map?.counts ?? []).map(row => `${row.count} ${row.label}`).join(" · ") || "No owner map counts yet.";
    uncertainty = "Map geometry is canonical V197; node labels and counts come from the owner ledger.";
    signals.push(...nodes.slice(0, 3).map(node => node.title));
  }

  if (focus === "orbits") {
    const orbits = (snapshot.orbits?.orbits ?? []).filter(row => row.kind !== "PERSONAL_BRIDGE");
    count = orbits.length;
    title = orbits.length ? `${orbits[0].title} + ${Math.max(0, orbits.length - 1)} Systems` : "No persisted Orbits yet";
    copy = orbits.length
      ? `${orbits.length} owner-owned Orbits · ${orbits.reduce((sum, row) => sum + Object.values(row.counts).reduce((inner, value) => inner + value, 0), 0)} held objects.`
      : "Create one System to open this lens.";
    uncertainty = "Only the signed-in owner's Orbits are queried.";
    signals.push(...orbits.slice(0, 3).map(row => row.title));
  }

  if (focus === "timeline") {
    const items = snapshot.timeline?.items ?? [];
    const latest = items[0];
    count = items.length;
    title = latest?.title ?? "No persisted Timeline event yet";
    copy = latest ? latest.body : "Complete one real action to create a Timeline event.";
    uncertainty = latest ? `${latest.provenance_label} · ${latest.kind.replaceAll("_", " ")}` : "No event provenance exists yet.";
    signals.push(...items.slice(0, 3).map(item => item.title));
  }

  if (focus === "insights") {
    const insight = snapshot.insights;
    const claim = insight?.claims[0];
    const claimText = typeof claim?.claim_text === "string" ? claim.claim_text : null;
    count = insight?.counts.claims ?? 0;
    title = claimText ?? "No candidate insight yet";
    copy = claimText ? "Candidate understanding from the owner-only evidence ledger." : "NUR will not invent advice before evidence exists.";
    uncertainty = `${insight?.counts.open_contradictions ?? 0} open contradictions · ${insight?.counts.review_queue ?? 0} awaiting review.`;
    signals.push(
      `${insight?.counts.claims ?? 0} candidate claims`,
      `${insight?.counts.predictions ?? 0} predictions`,
      `${insight?.counts.open_contradictions ?? 0} contradictions`,
    );
  }

  text(panel.querySelector(".universe-insight-title small"), "Persisted view");
  text(panel.querySelector(".universe-insight-title h2"), title);
  text(panel.querySelector(".universe-insight-copy"), copy);
  text(panel.querySelector(".insight-uncertainty p"), uncertainty);
  const signalSlots = [...panel.querySelectorAll<HTMLElement>(".signal-list span")];
  signalSlots.forEach((slot, index) => {
    slot.textContent = signals[index] ?? "No additional persisted signal";
  });
  text(panel.querySelector(".insight-strength span"), "Persisted records");
  text(panel.querySelector(".insight-strength b"), String(count));
  text(panel.querySelector(".insight-evidence small"), "Provenance");
  text(panel.querySelector(".insight-evidence b"), snapshot.timeline?.provenance_label ?? snapshot.map?.provenance_label ?? "owner_ledger");
  text(panel.querySelector(".insight-evidence span"), "No fake live metrics");
  text(panel.querySelector(".insight-revision span"), "Updated from the latest persisted snapshot.");
}

export function renderWorldLens(
  document: Document,
  snapshot: V197BridgeSnapshot,
  focus: string,
): void {
  renderVisibleLens(document, snapshot, focus);
  const lane = document.querySelector<HTMLElement>(".universe-system-lane");
  if (!lane) return;
  const cards = [...lane.querySelectorAll<HTMLElement>("article")];

  if (focus === "timeline") {
    const rows = snapshot.timeline?.items.slice(0, 3) ?? [];
    cards.forEach((card, index) => {
      const row = rows[index];
      setLaneCard(card, row?.kind.replaceAll("_", " ") ?? "owner timeline", row?.title ?? "No event", row ? shorten(row.body, 80) : "No persisted event in this slot.");
    });
    lane.setAttribute("aria-label", "Owner timeline summary");
    return;
  }

  if (focus === "orbits") {
    const rows = (snapshot.orbits?.orbits ?? []).filter(row => row.kind !== "PERSONAL_BRIDGE").slice(0, 3);
    cards.forEach((card, index) => {
      const row = rows[index];
      const held = row ? Object.values(row.counts).reduce((sum, value) => sum + value, 0) : 0;
      setLaneCard(card, row?.kind ?? "project orbit", row?.title ?? "No Orbit", row ? `${held} held objects · ${row.status.toLowerCase()}` : "No persisted Orbit in this slot.");
    });
    lane.setAttribute("aria-label", "Owner Orbits summary");
    return;
  }

  if (focus === "insights") {
    const insight = snapshot.insights;
    setLaneCard(cards[0], "candidate claims", number(insight?.counts.claims), "owner-only Omega ledger");
    setLaneCard(cards[1], "open contradictions", number(insight?.counts.open_contradictions), "needs review");
    setLaneCard(cards[2], "review queue", number(insight?.counts.review_queue), "no automatic promotion");
    lane.setAttribute("aria-label", "Owner insight summary");
    return;
  }

  const counts = snapshot.map?.counts ?? [];
  cards.forEach((card, index) => {
    const row = counts[index];
    setLaneCard(card, row?.label ?? "owner ledger", number(row?.count), row ? "persisted private data" : "No persisted count in this slot.");
  });
  lane.setAttribute("aria-label", "Owner map summary");
}

function renderInsight(document: Document, snapshot: V197BridgeSnapshot): void {
  const insights = snapshot.insights;
  const claim = insights?.claims[0];
  const contradiction = insights?.contradictions[0];
  const claimText = typeof claim?.claim_text === "string" ? claim.claim_text : null;
  const confidence = typeof claim?.confidence === "number" ? `${Math.round(claim.confidence * 100)}% confidence` : "awaiting owner evidence";
  const claimCount = typeof insights?.counts.claims === "number" ? insights.counts.claims : insights?.claims.length ?? 0;
  const contradictionCount = typeof insights?.counts.open_contradictions === "number"
    ? insights.counts.open_contradictions
    : insights?.contradictions.length ?? 0;
  const predictionCount = typeof insights?.counts.predictions === "number"
    ? insights.counts.predictions
    : insights?.predictions.length ?? 0;
  const reviewCount = typeof insights?.counts.review_queue === "number"
    ? insights.counts.review_queue
    : insights?.review_queue.length ?? 0;
  const openStep = snapshot.plans.flatMap(plan => plan.steps).find(step => !step.done);
  const latestEvent = snapshot.timeline?.items[0];

  ownText(document.querySelector(".system-badge"), "Candidate insight");
  text(document.querySelector(".universe-insight-title small"), claimText ? "Candidate claim" : "Evidence state");
  text(document.querySelector(".universe-insight-title h2"), claimText ?? "No candidate insight yet");
  text(document.querySelector(".universe-insight-copy"), claimText ? `Inferred from the owner ledger · ${confidence}.` : "NUR will not invent an insight before evidence exists.");
  const contradictionText = typeof contradiction?.description === "string" ? contradiction.description : "No open contradiction is persisted.";
  text(document.querySelector(".insight-uncertainty span"), "Open contradiction");
  text(document.querySelector(".insight-uncertainty p"), contradictionText);
  const signals = [
    `${claimCount} candidate ${claimCount === 1 ? "claim" : "claims"}`,
    `${contradictionCount} open ${contradictionCount === 1 ? "contradiction" : "contradictions"}`,
    `${predictionCount} unresolved ${predictionCount === 1 ? "prediction" : "predictions"}`,
  ];
  document.querySelectorAll<HTMLElement>(".signal-list span").forEach((slot, index) => {
    slot.textContent = signals[index] ?? "No additional persisted signal";
  });
  text(document.querySelector(".insight-opportunity small"), "Next persisted move");
  text(document.querySelector(".insight-opportunity b"), openStep?.title ?? "No persisted next move yet.");
  text(document.querySelector(".insight-strength span"), "Persisted claims");
  text(document.querySelector(".insight-strength b"), String(claimCount));
  const decorativeStrengthBar = document.querySelector<HTMLElement>(".insight-strength i");
  if (decorativeStrengthBar) {
    decorativeStrengthBar.hidden = true;
    decorativeStrengthBar.style.display = "none";
  }
  text(document.querySelector(".insight-evidence small"), "Owner evidence");
  text(document.querySelector(".insight-evidence b"), `${snapshot.timeline?.items.length ?? 0} persisted events`);
  text(document.querySelector(".insight-evidence span"), insights?.provenance_label ?? "owner_ledger");
  text(
    document.querySelector(".insight-revision span"),
    latestEvent ? `Latest persisted change: ${latestEvent.title}.` : `No persisted revision yet · ${reviewCount} awaiting review.`,
  );
  text(document.querySelector(".live-label"), "OWNER LEDGER");
}

function makeHonestResult(document: Document, mark: string, title: string, detail: string): HTMLElement {
  const article = document.createElement("article");
  const icon = document.createElement("i");
  icon.textContent = mark;
  const copy = document.createElement("div");
  const heading = document.createElement("b");
  heading.textContent = title;
  const body = document.createElement("span");
  body.textContent = detail;
  const status = document.createElement("small");
  status.textContent = "Local owner ledger · no invented external data";
  copy.append(heading, body, status);
  article.append(icon, copy);
  return article;
}

function renderResearch(document: Document, snapshot: V197BridgeSnapshot): void {
  text(document.querySelector("#universe-research .universe-card-head h2"), "Saved research questions, held honestly.");
  const results = document.querySelector<HTMLElement>("#universe-research .research-results");
  if (!results) return;
  empty(results);
  if (snapshot.researchBriefs.length === 0) {
    results.append(makeHonestResult(document, "⌕", "Research engine is not connected yet.", "Stage a question here; NUR saves it locally without inventing sources."));
    return;
  }
  snapshot.researchBriefs.slice(0, 4).forEach(row => {
    results.append(makeHonestResult(document, "R", row.question, row.summary || `Status: ${row.status.toLowerCase()} · provider ${row.provider_status.toLowerCase()}`));
  });
}

function renderHonestDisabledSurfaces(document: Document): void {
  text(document.querySelector("#universe-community .universe-card-head h2"), "Community is not connected in this Track A build.");
  const community = document.querySelector<HTMLElement>("#universe-community .community-items");
  if (community) {
    empty(community);
    community.append(makeHonestResult(document, "◎", "No fake people, replies, or rooms.", "Community ships in Track B after privacy, moderation, and translation boundaries are proven."));
  }
  document.querySelectorAll<HTMLElement>("[data-community-tab], [data-stage], .consultation-question button").forEach(control => {
    control.setAttribute("aria-disabled", "true");
    if (control.tagName === "BUTTON") (control as HTMLButtonElement).disabled = true;
  });
  text(document.querySelector("#universe-consult .universe-card-head h2"), "Consultation opens in Track B after group boundaries are proven.");
  text(document.querySelector("#universe-consult .consultation-question p"), "No fake room is active in this sellable vertical slice.");
  const ritual = document.querySelector<HTMLButtonElement>('[data-action="ritual"]');
  if (ritual) {
    ritual.textContent = "Rituals open in Track B";
    ritual.disabled = true;
    ritual.setAttribute("aria-disabled", "true");
    ritual.setAttribute("title", "Ritual scheduling is not connected in this Track A build.");
  }
  const editDirection = document.querySelector<HTMLButtonElement>("#page-plan .panel-top .tiny-link:not([data-page])");
  if (editDirection) {
    editDirection.dataset.trackAAction = "edit-direction";
    editDirection.textContent = "Direction editing opens in Track B";
    editDirection.disabled = true;
    editDirection.setAttribute("aria-disabled", "true");
    editDirection.setAttribute("title", "Plan direction editing is not connected in this Track A build.");
  }
}

export function hydrateTrackAV197(document: Document, snapshot: V197BridgeSnapshot): void {
  hydrateReadOnlyV197(document, snapshot);
  const locale = snapshot.preferences?.locale ?? snapshot.session.profile.locale ?? "en";
  const writingPreference = snapshot.preferences?.writing_preference ?? snapshot.session.profile.writing_preference ?? "default";
  applyV197Locale(document, locale, writingPreference);
  renderTalk(document, snapshot.talkThread);
  renderJournal(document, snapshot);
  renderPlans(document, snapshot.plans);
  renderSystems(document, snapshot);
  renderInsight(document, snapshot);
  renderWorldLens(document, snapshot, "universe");
  renderResearch(document, snapshot);
  renderHonestDisabledSurfaces(document);
  renderPersistedGlow(document, snapshot.glow);
  text(document.querySelector('[data-thread-action="glow"]'), "Glow this persisted Talk");
  document.querySelectorAll<HTMLElement>(".quiet-chip").forEach(chip => {
    if (chip.textContent?.toLowerCase().includes("live feed")) ownText(chip, "local owner ledger");
  });
  const voice = document.querySelector<HTMLElement>(".composer-action--voice");
  if (voice) {
    voice.setAttribute("aria-disabled", "true");
    voice.setAttribute("title", "Voice is not connected in this Track A build.");
  }

  const latestUserTalk = [...snapshot.talkThread].reverse().find(row => row.who === "user" && row.text);
  text(document.querySelector("#page-today .mini-thread"), latestUserTalk?.text ? `“${shorten(latestUserTalk.text, 170)}”` : "No persisted Talk signal yet.");
  const latestPlan = snapshot.plans[0];
  text(document.querySelector("#page-today .next-move h3"), latestPlan?.title ?? "Name one real next move.");
  text(document.querySelector("#page-today .next-move p:last-of-type"), latestPlan ? `${latestPlan.steps.filter(step => !step.done).length} open persisted steps.` : "A Plan will appear here after the server saves it.");
}
