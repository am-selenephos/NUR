import datetime as dt
import uuid
from dataclasses import dataclass

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import (
    CognitiveEvent,
    GlowBalance,
    GlowRewardEvent,
    GlowRule,
    GlowStreak,
    GlowTransaction,
    JournalEntry,
    Outcome,
    Plan,
    PlanStep,
)
from app.models._mixins import now_utc


@dataclass
class AwardResult:
    transaction: GlowTransaction
    balance: GlowBalance
    streak: GlowStreak | None
    idempotent_replay: bool


async def _owned_source(
    db: AsyncSession,
    *,
    owner_user_id: uuid.UUID,
    source_kind: str,
    source_id: uuid.UUID,
):
    models = {
        "COGNITIVE_EVENT": CognitiveEvent,
        "JOURNAL_ENTRY": JournalEntry,
        "PLAN": Plan,
        "PLAN_STEP": PlanStep,
        "OUTCOME": Outcome,
    }
    model = models.get(source_kind)
    if model is None:
        raise HTTPException(422, "Unsupported Glow source kind.")
    row = (await db.execute(select(model).where(
        model.id == source_id,
        model.owner_user_id == owner_user_id,
    ))).scalar_one_or_none()
    if row is None:
        raise HTTPException(404, "Glow source not found.")
    return row


def _validate_event_source(event_type: str, source_kind: str, source) -> None:
    expected = {
        "daily_checkin": "COGNITIVE_EVENT",
        "talk_meaningful": "COGNITIVE_EVENT",
        "journal_saved": "JOURNAL_ENTRY",
        "plan_created": "PLAN",
        "plan_step_completed": "PLAN_STEP",
        "task_made_smaller": "PLAN_STEP",
        "outcome_returned": "OUTCOME",
    }
    if expected.get(event_type) != source_kind:
        raise HTTPException(422, "Glow event does not match its source kind.")
    if event_type == "daily_checkin":
        payload = source.structured_payload or {}
        if source.event_kind != "SYSTEM_EVENT" or payload.get("type") != "today_checkin":
            raise HTTPException(409, "Daily check-in Glow requires a persisted check-in event.")
    if event_type == "talk_meaningful" and source.event_kind != "TALK_TURN":
        raise HTTPException(409, "Talk Glow requires a persisted Talk turn.")
    if event_type == "plan_step_completed" and not source.done:
        raise HTTPException(409, "Plan step Glow requires a completed step.")


async def _update_streak(
    db: AsyncSession,
    *,
    owner_user_id: uuid.UUID,
    streak_key: str | None,
) -> GlowStreak | None:
    if not streak_key:
        return None
    today = dt.datetime.now(dt.timezone.utc).date()
    row = (await db.execute(
        select(GlowStreak)
        .where(GlowStreak.owner_user_id == owner_user_id, GlowStreak.streak_key == streak_key)
        .with_for_update()
    )).scalar_one_or_none()
    if row is None:
        row = GlowStreak(
            owner_user_id=owner_user_id,
            streak_key=streak_key,
            current_count=1,
            best_count=1,
            last_event_date=today,
        )
        db.add(row)
        await db.flush()
        return row
    if row.last_event_date == today:
        return row
    yesterday = today - dt.timedelta(days=1)
    row.current_count = row.current_count + 1 if row.last_event_date == yesterday else 1
    row.best_count = max(row.best_count, row.current_count)
    row.last_event_date = today
    row.updated_at = now_utc()
    return row


async def award_glow(
    db: AsyncSession,
    *,
    owner_user_id: uuid.UUID,
    event_type: str,
    source_kind: str,
    source_id: uuid.UUID,
    orbit_id: uuid.UUID | None,
    idempotency_key: str,
) -> AwardResult:
    replay = (await db.execute(select(GlowTransaction).where(
        GlowTransaction.owner_user_id == owner_user_id,
        GlowTransaction.idempotency_key == idempotency_key,
    ))).scalar_one_or_none()
    if replay is not None:
        balance = (await db.execute(select(GlowBalance).where(
            GlowBalance.owner_user_id == owner_user_id,
        ))).scalar_one()
        rule = (await db.execute(select(GlowRule).where(GlowRule.event_type == replay.event_type))).scalar_one()
        streak = None
        if rule.streak_key:
            streak = (await db.execute(select(GlowStreak).where(
                GlowStreak.owner_user_id == owner_user_id,
                GlowStreak.streak_key == rule.streak_key,
            ))).scalar_one_or_none()
        return AwardResult(replay, balance, streak, True)

    rule = (await db.execute(select(GlowRule).where(
        GlowRule.event_type == event_type,
        GlowRule.active.is_(True),
    ))).scalar_one_or_none()
    if rule is None:
        raise HTTPException(422, "Unknown or inactive Glow event.")

    source = await _owned_source(
        db,
        owner_user_id=owner_user_id,
        source_kind=source_kind,
        source_id=source_id,
    )
    _validate_event_source(event_type, source_kind, source)

    if orbit_id is not None:
        source_orbit = getattr(source, "orbit_id", None)
        if source_orbit is not None and source_orbit != orbit_id:
            raise HTTPException(409, "Glow Orbit does not match its source.")

    if rule.daily_cap is not None:
        start = dt.datetime.combine(dt.datetime.now(dt.timezone.utc).date(), dt.time.min, tzinfo=dt.timezone.utc)
        awarded_today = int((await db.execute(select(func.coalesce(func.sum(GlowTransaction.final_points), 0)).where(
            GlowTransaction.owner_user_id == owner_user_id,
            GlowTransaction.event_type == event_type,
            GlowTransaction.reversed.is_(False),
            GlowTransaction.created_at >= start,
        ))).scalar_one())
        if awarded_today + rule.base_points > rule.daily_cap:
            raise HTTPException(409, "Daily Glow cap reached for this action.")

    balance = (await db.execute(
        select(GlowBalance).where(GlowBalance.owner_user_id == owner_user_id).with_for_update()
    )).scalar_one_or_none()
    if balance is None:
        balance = GlowBalance(owner_user_id=owner_user_id)
        db.add(balance)
        await db.flush()

    transaction = GlowTransaction(
        owner_user_id=owner_user_id,
        event_type=event_type,
        source_kind=source_kind,
        source_id=source_id,
        orbit_id=orbit_id,
        base_points=rule.base_points,
        multiplier=1,
        final_points=rule.base_points,
        reason=rule.description,
        idempotency_key=idempotency_key,
        anti_abuse_metadata={"source_verified": True, "daily_cap": rule.daily_cap},
    )
    db.add(transaction)
    await db.flush()
    balance.balance += transaction.final_points
    balance.lifetime_points += transaction.final_points
    balance.updated_at = now_utc()
    streak = await _update_streak(
        db,
        owner_user_id=owner_user_id,
        streak_key=rule.streak_key,
    )
    db.add(GlowRewardEvent(
        owner_user_id=owner_user_id,
        event_type=event_type,
        source_kind=source_kind,
        source_id=source_id,
        idempotency_key=idempotency_key,
        transaction_id=transaction.id,
        event_metadata={"final_points": transaction.final_points, "streak_key": rule.streak_key},
    ))
    return AwardResult(transaction, balance, streak, False)
