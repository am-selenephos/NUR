"""Project Orbits (amendment Gate 2): owner-bound project containers, their
decisions/references/constraints/open-questions, and the explicit source
allowlist (orbit_sources) that alone can ever be shared."""
import datetime as dt
import uuid

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import Identity, Scoped, require_csrf
from app.models import Decision, MemoryCandidate, Orbit, OrbitReference, OrbitSource, Outcome, Plan, ResearchDraft

router = APIRouter(prefix="/orbits", tags=["orbits"])

SOURCE_TABLES = {
    "DECISION": "decisions", "REFERENCE": "orbit_references", "JOURNAL_ENTRY": "journal_entries",
    "PLAN": "plans", "PLAN_STEP": "plan_steps", "OUTCOME": "outcomes",
    "COGNITIVE_EVENT": "cognitive_events", "RESEARCH_DRAFT": "research_drafts",
    "RESEARCH_BRIEF": "research_briefs", "RESEARCH_SOURCE_NOTE": "research_source_notes",
    "WEB_SIGNAL_NOTE": "web_signal_notes",
}


class OrbitIn(BaseModel):
    title: str
    kind: str = "PROJECT"
    description: str | None = None


class OrbitRow(BaseModel):
    id: uuid.UUID
    title: str
    kind: str
    description: str | None
    status: str
    created_at: dt.datetime
    model_config = {"from_attributes": True}


class OrbitStateOut(BaseModel):
    active_systems: int
    outcomes_returned: int
    insights_evolving: int
    open_questions: int
    research_staged: int
    plans_active: int
    live_status: str


@router.post("", response_model=OrbitRow, status_code=201, dependencies=[Depends(require_csrf)])
async def create_orbit(payload: OrbitIn, db: Scoped, identity: Identity) -> OrbitRow:
    user_id, _ = identity
    if payload.kind == "PERSONAL_BRIDGE":
        raise HTTPException(422, "The personal bridge orbit is created at registration.")
    orbit = Orbit(owner_user_id=user_id, title=payload.title, kind=payload.kind, description=payload.description)
    db.add(orbit)
    await db.commit()
    return OrbitRow.model_validate(orbit)


@router.get("", response_model=list[OrbitRow])
async def list_orbits(db: Scoped, identity: Identity) -> list[OrbitRow]:
    user_id, _ = identity
    rows = (await db.execute(select(Orbit).where(Orbit.owner_user_id == user_id).order_by(Orbit.created_at))).scalars()
    return [OrbitRow.model_validate(o) for o in rows]


@router.get("/current-state", response_model=OrbitStateOut)
async def current_state(db: Scoped, identity: Identity) -> OrbitStateOut:
    user_id, _ = identity
    counts = {}
    for key, stmt in {
        "active_systems": select(func.count(Orbit.id)).where(
            Orbit.owner_user_id == user_id,
            Orbit.kind != "PERSONAL_BRIDGE",
            Orbit.status == "ACTIVE",
        ),
        "outcomes_returned": select(func.count(Outcome.id)).where(Outcome.owner_user_id == user_id),
        "insights_evolving": select(func.count(MemoryCandidate.id)).where(
            MemoryCandidate.owner_user_id == user_id,
            MemoryCandidate.status == "CANDIDATE",
        ),
        "open_questions": select(func.count(OrbitReference.id)).where(
            OrbitReference.owner_user_id == user_id,
            OrbitReference.kind == "OPEN_QUESTION",
        ),
        "research_staged": select(func.count(ResearchDraft.id)).where(ResearchDraft.owner_user_id == user_id),
        "plans_active": select(func.count(Plan.id)).where(
            Plan.owner_user_id == user_id,
            Plan.status == "ACTIVE",
        ),
    }.items():
        counts[key] = int((await db.execute(stmt)).scalar_one())
    return OrbitStateOut(**counts, live_status="owner_ledger")


async def _owned_orbit(db: AsyncSession, user_id: uuid.UUID, orbit_id: uuid.UUID) -> Orbit:
    o = (await db.execute(select(Orbit).where(Orbit.id == orbit_id, Orbit.owner_user_id == user_id))).scalar_one_or_none()
    if not o:
        raise HTTPException(404, "Orbit not found.")
    return o


class DecisionIn(BaseModel):
    statement: str
    rationale: str | None = None


class DecisionOut(DecisionIn):
    id: uuid.UUID
    status: str
    created_at: dt.datetime
    model_config = {"from_attributes": True}


@router.post("/{orbit_id}/decisions", response_model=DecisionOut, status_code=201, dependencies=[Depends(require_csrf)])
async def add_decision(orbit_id: uuid.UUID, payload: DecisionIn, db: Scoped, identity: Identity) -> DecisionOut:
    user_id, _ = identity
    await _owned_orbit(db, user_id, orbit_id)
    d = Decision(owner_user_id=user_id, orbit_id=orbit_id, statement=payload.statement, rationale=payload.rationale)
    db.add(d)
    await db.commit()
    return DecisionOut.model_validate(d)


@router.get("/{orbit_id}/decisions", response_model=list[DecisionOut])
async def list_decisions(orbit_id: uuid.UUID, db: Scoped, identity: Identity) -> list[DecisionOut]:
    user_id, _ = identity
    await _owned_orbit(db, user_id, orbit_id)
    rows = (await db.execute(select(Decision).where(Decision.orbit_id == orbit_id, Decision.owner_user_id == user_id).order_by(Decision.created_at.desc()))).scalars()
    return [DecisionOut.model_validate(d) for d in rows]


class ReferenceIn(BaseModel):
    title: str
    body: str | None = None
    url: str | None = None
    kind: str = "REFERENCE"  # REFERENCE | CONSTRAINT | OPEN_QUESTION


class ReferenceOut(ReferenceIn):
    id: uuid.UUID
    created_at: dt.datetime
    model_config = {"from_attributes": True}


@router.post("/{orbit_id}/references", response_model=ReferenceOut, status_code=201, dependencies=[Depends(require_csrf)])
async def add_reference(orbit_id: uuid.UUID, payload: ReferenceIn, db: Scoped, identity: Identity) -> ReferenceOut:
    user_id, _ = identity
    await _owned_orbit(db, user_id, orbit_id)
    r = OrbitReference(owner_user_id=user_id, orbit_id=orbit_id, **payload.model_dump())
    db.add(r)
    await db.commit()
    return ReferenceOut.model_validate(r)


@router.get("/{orbit_id}/references", response_model=list[ReferenceOut])
async def list_references(orbit_id: uuid.UUID, db: Scoped, identity: Identity, kind: str | None = None) -> list[ReferenceOut]:
    user_id, _ = identity
    await _owned_orbit(db, user_id, orbit_id)
    q = select(OrbitReference).where(OrbitReference.orbit_id == orbit_id, OrbitReference.owner_user_id == user_id).order_by(OrbitReference.created_at.desc())
    if kind:
        q = q.where(OrbitReference.kind == kind)
    return [ReferenceOut.model_validate(r) for r in (await db.execute(q)).scalars()]


class SourceIn(BaseModel):
    source_kind: str
    source_id: uuid.UUID
    inclusion_mode: str = "FULL"


class SourceOut(SourceIn):
    id: uuid.UUID
    created_at: dt.datetime
    model_config = {"from_attributes": True}


@router.post("/{orbit_id}/sources", response_model=SourceOut, status_code=201, dependencies=[Depends(require_csrf)])
async def attach_source(orbit_id: uuid.UUID, payload: SourceIn, db: Scoped, identity: Identity) -> SourceOut:
    """Explicit allowlisting (amendment §3): the target row must exist AND be
    owned by the caller — verified here, and RLS re-verifies beneath."""
    user_id, _ = identity
    await _owned_orbit(db, user_id, orbit_id)
    table = SOURCE_TABLES.get(payload.source_kind)
    if not table:
        raise HTTPException(422, "Unknown source kind.")
    owned = (await db.execute(text(
        f"SELECT 1 FROM {table} WHERE id = :sid AND owner_user_id = :uid"),
        {"sid": str(payload.source_id), "uid": str(user_id)})).first()
    if not owned:
        raise HTTPException(404, "Source object not found among your owned objects.")
    src = OrbitSource(orbit_id=orbit_id, owner_user_id=user_id, **payload.model_dump())
    db.add(src)
    await db.commit()
    return SourceOut.model_validate(src)


@router.get("/{orbit_id}/sources", response_model=list[SourceOut])
async def list_sources(orbit_id: uuid.UUID, db: Scoped, identity: Identity) -> list[SourceOut]:
    user_id, _ = identity
    await _owned_orbit(db, user_id, orbit_id)
    rows = (await db.execute(select(OrbitSource).where(OrbitSource.orbit_id == orbit_id, OrbitSource.owner_user_id == user_id))).scalars()
    return [SourceOut.model_validate(s) for s in rows]
