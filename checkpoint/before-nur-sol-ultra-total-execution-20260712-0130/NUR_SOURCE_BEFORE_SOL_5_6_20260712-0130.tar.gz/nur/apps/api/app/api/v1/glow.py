import datetime as dt
import uuid

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy import select

from app.api.deps import Identity, Scoped, require_csrf
from app.models import GlowBalance, GlowStreak, GlowTransaction
from app.services.glow_service import award_glow


router = APIRouter(prefix="/glow", tags=["glow"])


class GlowRewardIn(BaseModel):
    event_type: str = Field(min_length=1, max_length=80)
    source_kind: str = Field(min_length=1, max_length=80)
    source_id: uuid.UUID
    orbit_id: uuid.UUID | None = None
    idempotency_key: str = Field(min_length=8, max_length=240)


class GlowTransactionOut(BaseModel):
    id: uuid.UUID
    event_type: str
    source_kind: str
    source_id: uuid.UUID
    final_points: int
    reason: str
    created_at: dt.datetime
    model_config = {"from_attributes": True}


class GlowStreakOut(BaseModel):
    streak_key: str
    current_count: int
    best_count: int
    last_event_date: dt.date | None
    repairs_remaining: int
    model_config = {"from_attributes": True}


class GlowRewardOut(BaseModel):
    transaction_id: uuid.UUID
    event_type: str
    awarded_points: int
    balance: int
    lifetime_points: int
    idempotent_replay: bool
    streak: GlowStreakOut | None


class GlowSummaryOut(BaseModel):
    balance: int
    lifetime_points: int
    recent_transactions: list[GlowTransactionOut]
    streaks: list[GlowStreakOut]


@router.post("/rewards", response_model=GlowRewardOut, status_code=201, dependencies=[Depends(require_csrf)])
async def reward(payload: GlowRewardIn, db: Scoped, identity: Identity) -> GlowRewardOut:
    owner_user_id, _ = identity
    result = await award_glow(
        db,
        owner_user_id=owner_user_id,
        event_type=payload.event_type,
        source_kind=payload.source_kind,
        source_id=payload.source_id,
        orbit_id=payload.orbit_id,
        idempotency_key=payload.idempotency_key,
    )
    await db.commit()
    return GlowRewardOut(
        transaction_id=result.transaction.id,
        event_type=result.transaction.event_type,
        awarded_points=result.transaction.final_points,
        balance=result.balance.balance,
        lifetime_points=result.balance.lifetime_points,
        idempotent_replay=result.idempotent_replay,
        streak=GlowStreakOut.model_validate(result.streak) if result.streak else None,
    )


@router.get("/summary", response_model=GlowSummaryOut)
async def summary(db: Scoped, identity: Identity) -> GlowSummaryOut:
    owner_user_id, _ = identity
    balance = (await db.execute(select(GlowBalance).where(
        GlowBalance.owner_user_id == owner_user_id,
    ))).scalar_one_or_none()
    transactions = (await db.execute(select(GlowTransaction).where(
        GlowTransaction.owner_user_id == owner_user_id,
        GlowTransaction.reversed.is_(False),
    ).order_by(GlowTransaction.created_at.desc()).limit(20))).scalars().all()
    streaks = (await db.execute(select(GlowStreak).where(
        GlowStreak.owner_user_id == owner_user_id,
    ).order_by(GlowStreak.updated_at.desc()))).scalars().all()
    return GlowSummaryOut(
        balance=balance.balance if balance else 0,
        lifetime_points=balance.lifetime_points if balance else 0,
        recent_transactions=[GlowTransactionOut.model_validate(row) for row in transactions],
        streaks=[GlowStreakOut.model_validate(row) for row in streaks],
    )
