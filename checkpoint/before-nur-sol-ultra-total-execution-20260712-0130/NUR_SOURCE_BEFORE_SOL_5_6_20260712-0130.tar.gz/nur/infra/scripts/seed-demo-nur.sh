#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"

if [[ ! -f .env ]]; then
  printf 'Missing .env. Run cp .env.example .env first.\n' >&2
  exit 1
fi

set -a
# shellcheck disable=SC1091
source .env
set +a

apps/api/.venv/bin/python - <<'PY'
import os
import sys

import httpx

API = os.environ.get("API_ORIGIN", "http://localhost:8000")
OWNER_EMAIL = os.environ.get("NUR_DEMO_OWNER_EMAIL", "owner@nur.app")
OWNER_PASSWORD = os.environ.get("NUR_DEMO_OWNER_PASSWORD", "owner-demo-pass-123")
RECIPIENT_EMAIL = os.environ.get("NUR_DEMO_RECIPIENT_EMAIL", "recipient@nur.app")
RECIPIENT_PASSWORD = os.environ.get("NUR_DEMO_RECIPIENT_PASSWORD", "recipient-demo-pass-123")


def csrf(client: httpx.Client) -> dict[str, str]:
    token = client.cookies.get("nur_csrf")
    return {"X-CSRF-Token": token} if token else {}


def ensure_user(client: httpx.Client, email: str, password: str, chosen_name: str) -> dict:
    r = client.post(f"{API}/api/v1/auth/register", json={
        "chosen_name": chosen_name,
        "email": email,
        "password": password,
        "consent": True,
    })
    if r.status_code == 201:
        return r.json()
    login = client.post(f"{API}/api/v1/auth/login", json={"email": email, "password": password})
    if login.status_code != 200:
        print(f"Could not register or login {email}: {r.status_code} {r.text} / {login.status_code} {login.text}", file=sys.stderr)
        raise SystemExit(1)
    return client.get(f"{API}/api/v1/auth/me").json()


def expect_json(response: httpx.Response, label: str) -> dict:
    if not response.is_success:
        print(f"{label} failed: {response.status_code} {response.text}", file=sys.stderr)
        response.raise_for_status()
    try:
        return response.json()
    except Exception as exc:
        print(f"{label} returned non-JSON: {response.status_code} {response.text[:600]}", file=sys.stderr)
        raise exc


def award_glow(client: httpx.Client, *, event_type: str, source_kind: str, source_id: str, orbit_id: str, idempotency_key: str) -> dict | None:
    response = client.post(f"{API}/api/v1/glow/rewards", headers=csrf(client), json={
        "event_type": event_type,
        "source_kind": source_kind,
        "source_id": source_id,
        "orbit_id": orbit_id,
        "idempotency_key": idempotency_key,
    })
    if response.status_code == 201:
        return response.json()
    if response.status_code == 409 and "cap" in response.text.lower():
        return None
    print(f"Glow seed failed: {response.status_code} {response.text}", file=sys.stderr)
    response.raise_for_status()
    return None


owner = httpx.Client(timeout=20)
recipient = httpx.Client(timeout=20)
owner_me = ensure_user(owner, OWNER_EMAIL, OWNER_PASSWORD, "Selene")
ensure_user(recipient, RECIPIENT_EMAIL, RECIPIENT_PASSWORD, "Recipient")

orbits = owner.get(f"{API}/api/v1/orbits").json()
core_systems = [
    ("Quiet Ambition", "CREATIVE", "Build meaningful work without abandoning quiet."),
    ("Rebuild", "CARE", "Recover capacity and rebuild from what is real."),
    ("Study", "RESEARCH", "Turn questions into grounded understanding."),
    ("Money", "PROJECT", "Build material freedom with evidence and intent."),
    ("Body", "CARE", "Keep embodied capacity inside every decision."),
    ("Connection", "CARE", "Hold relationships without losing the self."),
    ("Creation", "CREATIVE", "Move imagination into finished form."),
]
by_title = {row["title"]: row for row in orbits if row.get("kind") != "PERSONAL_BRIDGE"}
for title, kind, description in core_systems:
    if title in by_title:
        continue
    by_title[title] = expect_json(owner.post(f"{API}/api/v1/orbits", headers=csrf(owner), json={
        "title": title,
        "kind": kind,
        "description": description,
    }), f"create demo System {title}")
orbit = by_title["Quiet Ambition"]
owner.patch(f"{API}/api/v1/profile/preferences", headers=csrf(owner), json={
    "active_orbit_id": orbit["id"],
    "default_boundary": "PRIVATE_ORBIT",
}).raise_for_status()
plan = expect_json(owner.post(f"{API}/api/v1/plans", headers=csrf(owner), json={
    "title": "Omega v1 boot demo",
    "orbit_id": orbit["id"],
    "steps": [{"title": "Return one real outcome", "body": "Seeded by boot demo."}],
}), "create demo plan")
award_glow(owner, event_type="plan_created", source_kind="PLAN", source_id=plan["id"], orbit_id=orbit["id"], idempotency_key=f"seed-plan:{plan['id']}:created")
step_id = plan["steps"][0]["id"]
owner.post(f"{API}/api/v1/omega/predictions", headers=csrf(owner), json={
    "prediction_text": "The boot demo outcome will resolve the seeded prediction.",
    "expected_observation": "Boot demo outcome persisted",
    "plan_step_id": step_id,
    "confidence": 0.72,
}).raise_for_status()
owner.patch(f"{API}/api/v1/plan-steps/{step_id}", headers=csrf(owner), json={"done": True}).raise_for_status()
award_glow(owner, event_type="plan_step_completed", source_kind="PLAN_STEP", source_id=step_id, orbit_id=orbit["id"], idempotency_key=f"seed-step:{step_id}:completed")
outcome = expect_json(owner.post(f"{API}/api/v1/outcomes", headers=csrf(owner), json={
    "plan_step_id": step_id,
    "observed_result": "Boot demo outcome persisted and can resolve predictions.",
}), "create demo outcome")
award_glow(owner, event_type="outcome_returned", source_kind="OUTCOME", source_id=outcome["id"], orbit_id=orbit["id"], idempotency_key=f"seed-outcome:{outcome['id']}:returned")
owner.post(f"{API}/api/v1/cognition/events", headers=csrf(owner), json={
    "event_kind": "MODEL_RESPONSE",
    "content_text": "Model response: identity expansion may be a sensitive inferred preference and must wait for owner review.",
}).raise_for_status()
owner.post(f"{API}/api/v1/omega/claims", headers=csrf(owner), json={
    "claim_text": "Capsule law must not send raw owner memory to recipients.",
    "claim_type": "CONSTRAINT",
    "truth_status": "OBSERVED",
    "provenance_label": "OWNER_WRITTEN",
}).raise_for_status()
owner.post(f"{API}/api/v1/omega/claims", headers=csrf(owner), json={
    "claim_text": "We will send raw owner memory to recipients.",
    "claim_type": "DECISION",
    "truth_status": "HYPOTHESIS",
    "provenance_label": "MODEL_GENERATED",
}).raise_for_status()
owner.post(f"{API}/api/v1/omega/consolidate", headers=csrf(owner), json={"run_kind": "MANUAL"}).raise_for_status()
if os.environ.get("NUR_AI_PROVIDER") == "openai":
    print("Seed skipped live Talk model call; openai-smoke-local.sh validates provider output separately.")
else:
    talk = expect_json(owner.post(f"{API}/api/v1/cognition/talk", headers=csrf(owner), json={
        "message": "What changed after the boot demo outcome?",
        "locale": "en",
    }), "create demo Talk turn")
    award_glow(owner, event_type="talk_meaningful", source_kind="COGNITIVE_EVENT", source_id=talk["turn_event_id"], orbit_id=orbit["id"], idempotency_key=f"seed-talk:{talk['turn_event_id']}:meaningful")
journal = expect_json(owner.post(f"{API}/api/v1/journal", headers=csrf(owner), json={
    "body": "Boot demo journal: the interface must stay visual, private, and source-bound.",
    "orbit_id": orbit["id"],
}), "create demo Journal entry")
award_glow(owner, event_type="journal_saved", source_kind="JOURNAL_ENTRY", source_id=journal["id"], orbit_id=orbit["id"], idempotency_key=f"seed-journal:{journal['id']}:saved")
checkin = expect_json(owner.post(f"{API}/api/v1/cognition/events", headers=csrf(owner), json={
    "event_kind": "SYSTEM_EVENT",
    "content_text": "The demo Orbit is ready for one real move.",
    "structured_payload": {"type": "today_checkin", "provenance_label": "OWNER_WRITTEN"},
    "orbit_id": orbit["id"],
}), "create demo Today check-in")
award_glow(owner, event_type="daily_checkin", source_kind="COGNITIVE_EVENT", source_id=checkin["event"]["id"], orbit_id=orbit["id"], idempotency_key=f"seed-checkin:{checkin['event']['id']}:daily")
owner.post(f"{API}/api/v1/research-drafts", headers=csrf(owner), json={
    "question": "Which outside signal should be checked before claiming NUR is market-ready?",
    "notes": "Seeded research question; no live web fetch is performed.",
    "orbit_id": orbit["id"],
}).raise_for_status()
brief = expect_json(owner.post(f"{API}/api/v1/research/briefs", headers=csrf(owner), json={
    "question": "Which outside signal should be checked before claiming NUR is market-ready?",
    "summary": "Seeded local research brief; no live web fetch is performed.",
    "orbit_id": orbit["id"],
}), "create demo research brief")
owner.post(f"{API}/api/v1/research/source-notes", headers=csrf(owner), json={
    "title": "Local research source note",
    "note": "Owner-supplied source note for beta readiness; not fetched from the web.",
    "orbit_id": orbit["id"],
    "research_brief_id": brief["id"],
}).raise_for_status()
owner.post(f"{API}/api/v1/community/consultation-notes", headers=csrf(owner), json={
    "title": "Collaborator boundary review",
    "note": "Ask a collaborator whether the Orbit boundary is understandable without onboarding.",
    "collaborator_label": "future reviewer",
    "orbit_id": orbit["id"],
}).raise_for_status()
web_question = expect_json(owner.post(f"{API}/api/v1/web-signals/questions", headers=csrf(owner), json={
    "question": "Check whether privacy-first personal context tools explain revocation clearly.",
    "orbit_id": orbit["id"],
}), "create demo web signal question")
owner.post(f"{API}/api/v1/web-signals/notes", headers=csrf(owner), json={
    "title": "Revocation clarity signal",
    "note": "Local note only; no live web connector is enabled.",
    "orbit_id": orbit["id"],
    "web_signal_question_id": web_question["id"],
}).raise_for_status()
owner.get(f"{API}/api/v1/provider-capabilities").raise_for_status()

decision = expect_json(owner.post(f"{API}/api/v1/orbits/{orbit['id']}/decisions", headers=csrf(owner), json={
    "statement": "Capsules share only approved sources, never Omega owner memory.",
    "rationale": "Boot demo source boundary.",
}), "create capsule source decision")
reference = expect_json(owner.post(f"{API}/api/v1/orbits/{orbit['id']}/references", headers=csrf(owner), json={
    "title": "V197 visual contract",
    "body": "Bodoni, Crimson, deep black void, warm glass, holographic NUR, source-faithful stars.",
    "kind": "REFERENCE",
}), "create orbit reference")
constraint = expect_json(owner.post(f"{API}/api/v1/orbits/{orbit['id']}/references", headers=csrf(owner), json={
    "title": "Recipient boundary constraint",
    "body": "Recipients can ask only against included Capsule sources.",
    "kind": "CONSTRAINT",
}), "create orbit constraint")
source = expect_json(owner.post(f"{API}/api/v1/orbits/{orbit['id']}/sources", headers=csrf(owner), json={
    "source_kind": "DECISION",
    "source_id": decision["id"],
}), "attach capsule source")
owner.post(f"{API}/api/v1/orbits/{orbit['id']}/sources", headers=csrf(owner), json={
    "source_kind": "REFERENCE",
    "source_id": reference["id"],
}).raise_for_status()
owner.post(f"{API}/api/v1/orbits/{orbit['id']}/sources", headers=csrf(owner), json={
    "source_kind": "REFERENCE",
    "source_id": constraint["id"],
}).raise_for_status()
capsule = expect_json(owner.post(f"{API}/api/v1/orbits/{orbit['id']}/capsules", headers=csrf(owner), json={
    "title": "Omega isolation boot capsule",
    "purpose": "Show recipient sees approved context only.",
    "capability": "ASK_SCOPED_QUESTIONS",
    "orbit_source_ids": [source["id"]],
    "representations": {source["id"]: "FULL"},
}), "create demo capsule")
owner.post(f"{API}/api/v1/capsules/{capsule['id']}/grants", headers=csrf(owner), json={
    "recipient_email": RECIPIENT_EMAIL,
    "capability": "ASK_SCOPED_QUESTIONS",
}).raise_for_status()

print("Demo seed complete")
print(f"Owner: {OWNER_EMAIL} / {OWNER_PASSWORD}")
print(f"Recipient: {RECIPIENT_EMAIL} / {RECIPIENT_PASSWORD}")
web = os.environ.get('WEB_ORIGIN', 'http://localhost:5173')
print(f"Owner app: {web}")
print(f"Owner Talk: {web}/talk")
print(f"Owner Systems: {web}/systems")
print(f"Omega: {web}/universe/omega")
print(f"Omega Review: {web}/universe/omega/review")
print(f"Recipient Capsule: {web}/capsule/{capsule['id']}")
print(f"Owner user id: {owner_me['id']}")
PY
