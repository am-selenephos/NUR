import asyncio
import json

from app.ai.errors import AIOutputValidationError, AIProviderError, AIProviderMisconfigured
from app.ai.prompts import TALK_SYSTEM_PROMPT, talk_user_prompt
from app.ai.schemas import AIProviderResult, NURTalkOutput, TalkProviderRequest
from app.ai.structured_outputs import talk_json_schema
from app.core.config import get_settings

RETRYABLE_STATUS_CODES = {408, 429, 500, 502, 503, 504}
AUTH_STATUS_CODES = {401, 403}


class OpenAITalkProvider:
    name = "openai"

    def __init__(self) -> None:
        s = get_settings()
        if s.openai_api_key is None or not s.openai_model:
            raise AIProviderMisconfigured("OpenAI provider is missing OPENAI_API_KEY or NUR_OPENAI_MODEL.")
        try:
            from openai import AsyncOpenAI
        except Exception as exc:  # pragma: no cover - depends on installed optional package
            raise AIProviderMisconfigured("The openai Python package is not installed.") from exc
        self._settings = s
        self._client = AsyncOpenAI(
            api_key=s.openai_api_key.get_secret_value(),
            timeout=s.openai_request_timeout_seconds,
        )

    async def complete_private_talk(self, request: TalkProviderRequest) -> AIProviderResult:
        evidence = [r.model_dump() for r in request.retrieval]
        payload = {
            "model": self._settings.openai_model,
            "input": [
                {"role": "system", "content": TALK_SYSTEM_PROMPT},
                {
                    "role": "user",
                    "content": talk_user_prompt(
                        user_line=request.user_line,
                        evidence=evidence,
                        locale=request.locale,
                        writing_preference=request.writing_preference,
                        mode=request.mode,
                        omega_context=request.omega_context,
                    ),
                },
            ],
            "text": {"format": talk_json_schema()},
            "reasoning": {"effort": self._settings.openai_reasoning_effort},
        }
        response = await self._create_response(payload)
        parsed = _extract_response_json(response)
        try:
            output = NURTalkOutput.model_validate(parsed)
        except Exception as exc:
            raise AIOutputValidationError("OpenAI response did not match NURTalkOutput.") from exc
        return AIProviderResult(
            provider=self.name,
            model=self._settings.openai_model,
            available=True,
            output=output,
            usage=getattr(response, "usage", None).model_dump() if getattr(response, "usage", None) else {},
            raw_response_id=getattr(response, "id", None),
        )

    async def _create_response(self, payload: dict):
        """Retry transient provider failures once; never retry auth/config errors."""
        for attempt in range(2):
            try:
                return await self._client.responses.create(**payload)
            except Exception as exc:
                if _is_auth_error(exc):
                    raise AIProviderMisconfigured("OpenAI authentication failed; rotate or replace the server key.") from exc
                if attempt == 0 and _is_retryable_error(exc):
                    continue
                raise AIProviderError("OpenAI request failed closed.") from exc
        raise AIProviderError("OpenAI request failed closed.")


def _extract_response_json(response) -> dict:
    text = getattr(response, "output_text", None)
    if not text:
        chunks: list[str] = []
        for item in getattr(response, "output", []) or []:
            for content in getattr(item, "content", []) or []:
                value = getattr(content, "text", None)
                if value:
                    chunks.append(value)
        text = "\n".join(chunks)
    if not text:
        raise AIOutputValidationError("OpenAI response contained no text output.")
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise AIOutputValidationError("OpenAI response was not valid JSON.") from exc


def _status_code(exc: Exception) -> int | None:
    value = getattr(exc, "status_code", None) or getattr(exc, "status", None)
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _is_auth_error(exc: Exception) -> bool:
    status = _status_code(exc)
    if status in AUTH_STATUS_CODES:
        return True
    name = exc.__class__.__name__.lower()
    return "auth" in name or "permission" in name


def _is_retryable_error(exc: Exception) -> bool:
    status = _status_code(exc)
    if status in RETRYABLE_STATUS_CODES:
        return True
    return isinstance(exc, (TimeoutError, asyncio.TimeoutError)) or "timeout" in exc.__class__.__name__.lower()
