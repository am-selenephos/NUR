/**
 * Reserved for Phase 2. V197 has an existing Talk stream slot, but Phase 1 is
 * read-only hydration only and deliberately opens no stream or write channel.
 */
export class V197StreamClient {
  get active(): false {
    return false;
  }
}
