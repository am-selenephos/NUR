#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

WEB_URL="${WEB_ORIGIN:-http://localhost:5173}"
API_URL="${API_ORIGIN:-http://localhost:8000}"

open_nur() {
  bash "$ROOT/infra/scripts/open-nur.sh" >/dev/null 2>&1 || true
}

configured_openai() {
  [[ -f "$ROOT/.env.local" ]] \
    && grep -qE '^OPENAI_API_KEY=.+$' "$ROOT/.env.local" \
    && grep -qE '^NUR_OPENAI_MODEL=.+$' "$ROOT/.env.local"
}

running_provider() {
  curl -fsS --max-time 2 "$API_URL/healthz" 2>/dev/null \
    | python3 -c 'import json,sys; print(json.load(sys.stdin).get("ai_provider", ""))' 2>/dev/null \
    || true
}

MODE="${1:-auto}"
if [[ "$MODE" == "auto" ]]; then
  if configured_openai; then
    MODE="openai"
  else
    MODE="disabled"
  fi
fi

case "$MODE" in
  openai|disabled)
    current="$(running_provider)"
    if [[ "$current" == "$MODE" ]] && curl -fsS --max-time 2 "$WEB_URL" >/dev/null 2>&1; then
      printf 'NUR is already running in %s mode. Opening %s\n' "$MODE" "$WEB_URL"
      bash "$ROOT/RUN_NUR.sh" status
      open_nur
      exit 0
    fi
    if [[ "$MODE" == "openai" ]]; then
      printf 'Starting the complete NUR universe with the configured local OpenAI provider.\n'
    else
      printf 'Starting the complete NUR universe in honest disabled-provider mode.\n'
      printf 'To enable real Talk later: bash infra/scripts/configure-openai-local.sh\n'
    fi
    exec bash "$ROOT/RUN_NUR.sh" "$MODE"
    ;;
  status|stop|logs|doctor|seed|reset-demo|package)
    exec bash "$ROOT/RUN_NUR.sh" "$MODE"
    ;;
  *)
    printf 'Unknown mode: %s\n' "$MODE" >&2
    printf 'Use: auto, openai, disabled, status, stop, logs, doctor, seed, reset-demo, or package.\n' >&2
    exit 2
    ;;
esac
