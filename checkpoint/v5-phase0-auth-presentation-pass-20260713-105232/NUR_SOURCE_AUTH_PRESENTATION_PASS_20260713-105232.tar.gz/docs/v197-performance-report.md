# V197 Performance And Runtime Report

Date: 2026-07-11

## Proven

- Production bridge build: `62.54 kB`, `20.08 kB` gzip.
- No React visual mount or visible `#root`.
- One idempotent polish style node and one Track A action binding per universe document.
- Snapshot hydration batches owner reads through `V197ApiClient.snapshot()` rather than one visual component tree per panel.
- Stage screenshots wait for fonts, two animation frames, and the 340ms canonical stage transition.
- Mobile command/lens rows contain overflow locally; document horizontal overflow assertion passes.
- Reduced-motion behavior remains canonical V197 behavior.

## Cross-browser result

- Chromium desktop owner journey: pass.
- Chromium Pixel 5 emulation: pass.
- Official Playwright WebKit / iPhone 13 emulation: pass.
- WebKit proof was run in `mcr.microsoft.com/playwright:v1.61.1-jammy`; it was not substituted with Chromium.

## Honest limits

- No synthetic FPS number or fake 60fps claim was produced.
- Canonical V197 still contains many animated particles and backdrop effects; GPU/low-power quality tiers remain Track B work.
- Canonical WebKit retains a known top-left compositing strip already present in the Phase 1 baseline. Disabling its topbar backdrop filter made WebKit paint blank, so the risky workaround was rejected.
- Long-task and memory profiles need a dedicated real-device session before a production performance claim.
