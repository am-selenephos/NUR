# NUR

NUR is a local-first scoped beta for private project orbit work: Talk, Systems,
Project Orbit, Context Capsules, and the hidden NUR-Omega research layer.

This repository is bootable in local development mode with AI disabled by
default. OpenAI mode is server-only and must be configured with
`infra/scripts/configure-openai-local.sh`, which writes an ignored `.env.local`.
Do not place API keys in source, screenshots, logs, or zip artifacts.

## Quick Boot

```bash
bash RUN_NUR.sh
```

Open `http://localhost:5173`.

The root runner starts Postgres, Redis, FastAPI, the worker, Omega scheduler,
Vite, demo seed, health checks, and browser open as one local system. Use
`bash RUN_NUR.sh status`, `logs`, `seed`, `stop`, `doctor`, `reset-demo`, or
`package` for follow-up operations.

## Main Surfaces

- Web app: `apps/web`
- API: `apps/api`
- Shared TypeScript package: `packages/shared-types`
- Postgres/Redis compose: `docker-compose.yml`, `docker-compose.dev.yml`
- Boot scripts: `infra/scripts`
- Alembic migrations: `apps/api/alembic/versions`

## Omega v1

Omega is a research layer, not a consciousness, AGI, sentience, soul, or
autonomous real-world actor. It stores owner-scoped experiences, claims,
evidence edges, contradictions, predictions, learning proposals, review queue
items, and consolidation runs under forced Postgres RLS.

The hidden UI is available only when `VITE_NUR_ENABLE_OMEGA_RESEARCH=true`:

- `/universe/omega`
- `/universe/omega/review`

## Tests

```bash
python -m pytest apps/api/app/tests -q
npm --workspace apps/web run typecheck
npm --workspace apps/web test -- --run
VITE_NUR_ENABLE_OMEGA_RESEARCH=true npm --workspace apps/web run e2e -- e2e/omega-research.spec.ts --project=chromium-desktop
```

See `QUICKSTART_BOOT.md`, `RUNBOOK.md`, `DEMO_SCRIPT.md`, and
`SECURITY_NOTES.md` for the full local flow.
